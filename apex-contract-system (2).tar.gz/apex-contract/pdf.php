<?php
// ══════════════════════════════════════════════
//  APEX — PDF İxrac Nöqtəsi
//  pdf.php
// ══════════════════════════════════════════════
require_once 'config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';
require_once 'includes/helpers.php';
require_once 'includes/pdf_builder.php';

$token    = trim($_GET['t'] ?? '');
$id       = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$isPublic = (bool)$token;

// İcazə yoxlaması
if (!$isPublic && !is_logged_in()) {
    http_response_code(403);
    die('İcazə yoxdur. <a href="login.php">Giriş</a>');
}

try {
    if ($isPublic) {
        $st = db()->prepare("SELECT * FROM contracts WHERE sign_token = ?");
        $st->execute([$token]);
    } else {
        $st = db()->prepare("SELECT * FROM contracts WHERE id = ?");
        $st->execute([$id]);
    }

    $contract = $st->fetch();
    if (!$contract) {
        http_response_code(404);
        die('Müqavilə tapılmadı.');
    }

    // Yalnız imzalanmış müqavilə — public PDF
    if ($isPublic && $contract['status'] !== 'signed') {
        http_response_code(403);
        die('PDF yalnız imzalanmış müqavilə üçün mövcuddur.');
    }

    $company = ensure_settings();
    $c       = fmt_contract($contract);

    $pdfBytes = build_contract_pdf($c, $company);

    $filename = 'muqavile-' . preg_replace('/[^a-zA-Z0-9\-]/', '', $c['contract_no']) . '.pdf';

    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . strlen($pdfBytes));
    header('Cache-Control: private, no-cache, no-store');
    echo $pdfBytes;
    exit;

} catch (PDOException $e) {
    http_response_code(500);
    die('DB xətası.');
} catch (Throwable $e) {
    http_response_code(500);
    die('PDF yaradılarkən xəta baş verdi: ' . $e->getMessage());
}
