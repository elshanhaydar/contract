<?php
// ══════════════════════════════════════════════
//  APEX — Müştəri İmza Səhifəsi v2
//  sign.php
// ══════════════════════════════════════════════
require_once 'config.php';
$token = trim($_GET['t'] ?? '');
if (!$token) { http_response_code(400); die('<h2>Keçərsiz link.</h2>'); }
?>
<!DOCTYPE html>
<html lang="az">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Apex Industries — Müqavilə İmzalama</title>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600;700&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/sign.css">
</head>
<body>

<!-- HEADER -->
<div class="sign-header">
  <div class="sh-logo">
    <div class="sh-emblem">A</div>
    <div>
      <div class="sh-name">Apex Industries</div>
      <div class="sh-sub">MMC</div>
    </div>
  </div>
  <div class="sh-secure">🔒 Təhlükəsiz İmza</div>
</div>
<div class="progress-bar"><div class="progress-fill" id="progressFill"></div></div>

<div class="container">

  <!-- Loading -->
  <div class="state-screen active" id="screenLoading">
    <div class="state-icon">⏳</div>
    <div class="state-title">Yüklənir...</div>
    <div class="state-body">Müqavilə məlumatları hazırlanır, zəhmət olmasa gözləyin</div>
  </div>

  <!-- Error -->
  <div class="state-screen" id="screenError">
    <div class="state-icon">❌</div>
    <div class="state-title">Xəta Baş Verdi</div>
    <div class="state-body" id="errBody">Müqavilə tapılmadı.</div>
  </div>

  <!-- Cancelled -->
  <div class="state-screen" id="screenCancelled">
    <div class="state-icon">🚫</div>
    <div class="state-title">Müqavilə Ləğv Edilib</div>
    <div class="state-body">Bu müqavilə ləğv edilmişdir. Ətraflı məlumat üçün Apex Industries ilə əlaqə saxlayın.</div>
  </div>

  <!-- Already signed -->
  <div class="state-screen" id="screenAlreadySigned">
    <div class="state-icon">✅</div>
    <div class="state-title">Artıq İmzalanıb</div>
    <div class="state-body" id="alreadySignedBody">Bu müqavilə artıq imzalanmışdır.</div>
    <a class="btn-pdf" href="pdf.php?t=<?= htmlspecialchars($token) ?>" target="_blank">⬇️ PDF Müqaviləni Endir</a>
  </div>

  <!-- Success -->
  <div class="state-screen" id="screenSuccess" style="display:none">
    <div class="success-circle">✅</div>
    <div class="state-title">Müqavilə Uğurla İmzalandı!</div>
    <div class="success-no" id="successNo"></div>
    <div class="state-body">
      İmzalanma tarixi: <strong id="successDate"></strong><br>
      PDF-i endirin, müqavilənizin surətini saxlayın.
    </div>
    <img id="sigPreview" class="sig-preview" src="" alt="İmza">
    <br><br>
    <a class="btn-pdf" id="pdfDownloadBtn" href="#" target="_blank">⬇️ İmzalanmış Müqaviləni PDF Endir</a>
  </div>

  <!-- CONTRACT -->
  <div id="screenContract" style="display:none">

    <div class="contract-card">

      <!-- ── BAŞLIQ ── -->
      <div class="cc-header">
        <div class="cc-top">
          <div>
            <div class="cc-company" id="cCompany">Apex Industries MMC</div>
            <div class="cc-company-sub">SATIŞ MÜQAVİLƏSİ</div>
            <div class="cc-company-sub" style="margin-top:4px" id="cVoen"></div>
          </div>
          <div style="text-align:right">
            <div class="cc-no-label">Müqavilə №</div>
            <div class="cc-no-val" id="cNo">—</div>
            <div class="cc-no-label" style="margin-top:4px" id="cDate"></div>
          </div>
        </div>
      </div>

      <!-- §1 TƏRƏFLƏR -->
      <div class="cc-section">
        <div class="sec-title">§1 — MÜQAVİLƏNİN TƏRƏFLƏRİ</div>
        <div class="parties-grid">
          <div class="party-box" id="partyCompany"></div>
          <div class="party-box" id="partyClient"></div>
        </div>
      </div>

      <!-- §2 MALLAR -->
      <div class="cc-section">
        <div class="sec-title">§2 — MALLARIN / XİDMƏTLƏRİN SİYAHISI</div>
        <div id="itemsSection"></div>
        <div id="totalsBox"></div>
      </div>

      <!-- §3 ÖDƏNİŞ -->
      <div class="cc-section">
        <div class="sec-title">§3 — ÖDƏNİŞ ŞƏRTLƏRI</div>
        <div id="paymentBox"></div>
      </div>

      <!-- §4 MÜQAVİLƏ ŞƏRTLƏRİ -->
      <div class="cc-section" id="termsSection" style="display:none">
        <div class="sec-title">§4 — MÜQAVİLƏ ŞƏRTLƏRİ VƏ ÖHDƏLIKLƏR</div>
        <div class="terms-box" id="termsText"></div>
      </div>

      <!-- §5 QEYDLƏR -->
      <div class="cc-section" id="notesSection" style="display:none">
        <div class="sec-title">§5 — ƏLAVƏ QEYDLƏR</div>
        <p id="notesText" style="font-size:13.5px;color:var(--text-soft);line-height:1.75"></p>
      </div>

    </div><!-- /contract-card -->

    <!-- ── İMZA SAHƏSİ ── -->
    <div class="sign-area">
      <div class="sign-area-head">
        <div class="sign-area-title">✍️ Elektron İmza</div>
        <div style="display:flex;gap:8px;align-items:center">
          <span style="font-size:11.5px;color:var(--text-light)">Siçan və ya barmaq ilə imzalayın</span>
          <button class="canvas-clear" onclick="clearSignature()">🗑 Sıfırla</button>
        </div>
      </div>
      <div class="sign-area-body">

        <!-- Canvas -->
        <div class="canvas-wrap" id="canvasWrap">
          <canvas id="signCanvas"></canvas>
          <div class="canvas-placeholder" id="canvasPlaceholder">
            <div class="cp-icon">✍️</div>
            <div class="cp-text">Buraya imzanızı atın</div>
            <div class="cp-sub">Siçan ilə klikləyib çəkin və ya barmağınızla toxunun</div>
          </div>
        </div>

        <!-- Razılıq -->
        <div class="agreement-box" style="margin-top:18px">
          <div class="agreement-text">
            İmzalamadan əvvəl <button type="button" class="terms-link" id="openTermsBtn" onclick="openTermsModal()">📄 Müqavilə Şərtlərini oxuyun</button> — şərtləri oxuyub qəbul etdikdən sonra imza sahəsi aktiv olacaq.
          </div>
          <div class="terms-status" id="termsStatus" style="display:none">
            <span class="ts-check">✅</span>
            <span class="ts-text">Şərtlər oxundu və qəbul edildi</span>
            <button type="button" class="ts-reread" onclick="openTermsModal()">Yenidən oxu</button>
          </div>
          <label class="agreement-check" id="agreeCheckLabel">
            <input type="checkbox" id="agreeCheck">
            <span>Müqavilənin bütün şərtlərini oxudum və tam qəbul edirəm</span>
          </label>
        </div>

        <!-- Buttons -->
        <button class="btn-sign" id="btnSign" disabled>
          ✍️ Müqaviləni İmzala
        </button>
        <button class="btn-sec" onclick="window.print()">🖨️ Çap et</button>
      </div>
    </div>

  </div><!-- /screenContract -->
</div><!-- /container -->

<div class="toast" id="toast"></div>

<!-- ══════════════════════════════════════
     TERMS MODAL
══════════════════════════════════════ -->
<div class="terms-modal-overlay" id="termsModal" onclick="handleModalOverlayClick(event)">
  <div class="terms-modal">
    <div class="tm-head">
      <div>
        <div class="tm-title">📄 Müqavilə Şərtləri</div>
        <div class="tm-subtitle">§4 — Müqavilə Şərtləri və Öhdəliklər</div>
      </div>
      <button class="tm-close" onclick="closeTermsModal()" title="Bağla">✕</button>
    </div>

    <div class="tm-progress-wrap">
      <div class="tm-progress-bar">
        <div class="tm-progress-fill" id="tmProgressFill"></div>
      </div>
      <span class="tm-progress-label" id="tmProgressLabel">0% oxundu</span>
    </div>

    <div class="tm-body" id="tmBody">
      <div class="tm-content" id="tmContent">
        <!-- JS tərəfindən doldurulacaq -->
      </div>
    </div>

    <div class="tm-foot">
      <div class="tm-foot-left">
        <div class="tm-read-hint" id="tmReadHint">
          ⬇️ Aşağı sürüşdürərək bütün şərtləri oxuyun
        </div>
        <div class="tm-read-done" id="tmReadDone" style="display:none">
          ✅ Şərtlər tam oxundu
        </div>
      </div>
      <div class="tm-foot-btns">
        <button class="tm-btn-cancel" onclick="closeTermsModal()">Bağla</button>
        <button class="tm-btn-accept" id="tmAcceptBtn" onclick="acceptTerms()" disabled>
          ✅ Oxudum, Qəbul Edirəm
        </button>
      </div>
    </div>
  </div>
</div>

<script src="assets/js/sign.js"></script>
</body>
</html>
