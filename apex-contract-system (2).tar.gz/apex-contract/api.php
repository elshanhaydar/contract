<?php
// ══════════════════════════════════════════════
//  APEX INDUSTRIES MMC — API v2
//  api.php
// ══════════════════════════════════════════════
require_once 'config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';
require_once 'includes/helpers.php';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');

$method = $_SERVER['REQUEST_METHOD'];
$action = trim($_GET['action'] ?? '');
$id     = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$token  = trim($_GET['token'] ?? '');

$publicActions = ['sign_get', 'sign_submit'];

if (!in_array($action, $publicActions, true)) {
    if (!is_logged_in()) err('Giriş tələb olunur', 401);
}

try {

    // ══ MÜQAVİLƏLƏR ══════════════════════════════
    if ($action === 'contracts') {

        if ($method === 'GET') {
            $where = []; $params = [];
            if (!empty($_GET['status'])) {
                $allowed = ['pending','sent','signed','cancelled'];
                if (in_array($_GET['status'], $allowed, true)) { $where[] = 'status = ?'; $params[] = $_GET['status']; }
            }
            if (!empty($_GET['search'])) {
                $q       = '%' . $_GET['search'] . '%';
                $where[] = '(fname LIKE ? OR lname LIKE ? OR contract_no LIKE ? OR idnum LIKE ? OR phone LIKE ?)';
                $params  = array_merge($params, [$q,$q,$q,$q,$q]);
            }
            $sql  = "SELECT * FROM contracts"
                  . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
                  . " ORDER BY created_at DESC";
            $stmt = db()->prepare($sql); $stmt->execute($params);
            json_out(array_map('fmt_contract', $stmt->fetchAll()));
        }

        if ($method === 'POST') {
            $d = body();
            if (empty($d['fname']))   err('Ad boş ola bilməz');
            if (empty($d['lname']))   err('Soyad boş ola bilməz');
            if (empty($d['idnum']))   err('Şəxsiyyət vəsiqəsi boş ola bilməz');
            if (empty($d['phone']))   err('Telefon boş ola bilməz');
            if (empty($d['address'])) err('Ünvan boş ola bilməz');

            $no    = ensure_unique_no();
            $tok   = gen_token();
            $items = json_encode($d['items'] ?? [], JSON_UNESCAPED_UNICODE);
            $vatIn = isset($d['vatIncluded']) ? (int)(bool)$d['vatIncluded'] : 1;

            $stmt = db()->prepare("INSERT INTO contracts
                (contract_no,sign_token,status,
                 fname,lname,patronym,dob,idnum,fin,idissue,idexpiry,idauth,
                 address,delivery,phone,email,
                 items,vat_included,subtotal,vat,total,deposit,remaining,
                 deposit_date,final_date,pay_method,currency,
                 install_date,warranty,notes)
                VALUES (?,?,'pending', ?,?,?,?,?,?,?,?,?, ?,?,?,?, ?,?,?,?,?,?,?, ?,?,?,?, ?,?,?)");
            $stmt->execute([
                $no,$tok,
                s($d['fname']??''),s($d['lname']??''),$d['patronym']??null,
                $d['dob']??null,s($d['idnum']??''),$d['fin']??null,
                $d['idissue']??null,$d['idexpiry']??null,$d['idauth']??null,
                s($d['address']??''),$d['delivery']??null,
                s($d['phone']??''),$d['email']??null,
                $items,$vatIn,
                (float)($d['subtotal']??0),(float)($d['vat']??0),(float)($d['total']??0),
                (float)($d['deposit']??0),(float)($d['remaining']??0),
                $d['depositDate']??null,$d['finalDate']??null,
                $d['payMethod']??'Nağd',$d['currency']??'AZN',
                $d['installDate']??null,$d['warranty']??'12 ay',
                $d['notes']??null,
            ]);
            $lid = db()->lastInsertId();
            $st2 = db()->prepare("SELECT * FROM contracts WHERE id=?"); $st2->execute([$lid]);
            json_out(fmt_contract($st2->fetch()), 201);
        }
    }

    // ══ TEK MÜQAVİLƏ ════════════════════════════
    if ($action === 'contract' && $id) {

        if ($method === 'GET') {
            $st = db()->prepare("SELECT * FROM contracts WHERE id=?"); $st->execute([$id]);
            $row = $st->fetch();
            if (!$row) err('Tapılmadı', 404);
            json_out(fmt_contract($row));
        }

        if ($method === 'PUT') {
            $d = body(); $sets = []; $params = [];
            $strFields = ['status','fname','lname','patronym','dob','idnum','fin',
                          'idissue','idexpiry','idauth','address','delivery',
                          'phone','email','warranty','notes','currency'];
            $map = ['payMethod'=>'pay_method','depositDate'=>'deposit_date',
                    'finalDate'=>'final_date','installDate'=>'install_date'];
            foreach ($strFields as $f) {
                if (array_key_exists($f,$d)) { $sets[] = "`$f`=?"; $params[] = $d[$f]; }
            }
            foreach ($map as $camel=>$col) {
                if (array_key_exists($camel,$d)) { $sets[] = "`$col`=?"; $params[] = $d[$camel]; }
            }
            foreach (['subtotal','vat','total','deposit','remaining'] as $n) {
                if (isset($d[$n])) { $sets[] = "`$n`=?"; $params[] = (float)$d[$n]; }
            }
            if (array_key_exists('vatIncluded',$d)) { $sets[] = "`vat_included`=?"; $params[] = (int)(bool)$d['vatIncluded']; }
            if (isset($d['items'])) { $sets[] = "`items`=?"; $params[] = json_encode($d['items'],JSON_UNESCAPED_UNICODE); }
            if ($sets) { $params[] = $id; db()->prepare("UPDATE contracts SET ".implode(',',$sets)." WHERE id=?")->execute($params); }
            $st = db()->prepare("SELECT * FROM contracts WHERE id=?"); $st->execute([$id]);
            json_out(fmt_contract($st->fetch()));
        }

        if ($method === 'DELETE') {
            db()->prepare("DELETE FROM contracts WHERE id=?")->execute([$id]);
            json_out(['ok'=>true]);
        }
    }

    // ══ GÖNDƏR ══════════════════════════════════
    if ($action === 'send' && $id && $method === 'POST') {
        $st = db()->prepare("SELECT status FROM contracts WHERE id=?"); $st->execute([$id]);
        $row = $st->fetch();
        if (!$row) err('Tapılmadı',404);
        if ($row['status']==='cancelled') err('Ləğv edilmiş müqavilə göndərilə bilməz');
        db()->prepare("UPDATE contracts SET status='sent',sent_at=NOW() WHERE id=?")->execute([$id]);
        $st2 = db()->prepare("SELECT * FROM contracts WHERE id=?"); $st2->execute([$id]);
        json_out(fmt_contract($st2->fetch()));
    }

    // ══ LƏĞV ET ═════════════════════════════════
    if ($action === 'cancel' && $id && $method === 'POST') {
        $st = db()->prepare("SELECT status FROM contracts WHERE id=?"); $st->execute([$id]);
        $row = $st->fetch();
        if (!$row) err('Tapılmadı',404);
        if ($row['status']==='signed') err('İmzalanmış müqavilə ləğv edilə bilməz');
        db()->prepare("UPDATE contracts SET status='cancelled' WHERE id=?")->execute([$id]);
        $st2 = db()->prepare("SELECT * FROM contracts WHERE id=?"); $st2->execute([$id]);
        json_out(fmt_contract($st2->fetch()));
    }

    // ══ STATİSTİKA ══════════════════════════════
    if ($action === 'stats' && $method === 'GET') {
        $pdo = db();
        $stats = [];
        $stats['total']         = (int)$pdo->query("SELECT COUNT(*) FROM contracts")->fetchColumn();
        $stats['pending']       = (int)$pdo->query("SELECT COUNT(*) FROM contracts WHERE status='pending'")->fetchColumn();
        $stats['sent']          = (int)$pdo->query("SELECT COUNT(*) FROM contracts WHERE status='sent'")->fetchColumn();
        $stats['signed']        = (int)$pdo->query("SELECT COUNT(*) FROM contracts WHERE status='signed'")->fetchColumn();
        $stats['cancelled']     = (int)$pdo->query("SELECT COUNT(*) FROM contracts WHERE status='cancelled'")->fetchColumn();
        $stats['total_amount']  = (float)$pdo->query("SELECT COALESCE(SUM(total),0) FROM contracts WHERE status!='cancelled'")->fetchColumn();
        $stats['signed_amount'] = (float)$pdo->query("SELECT COALESCE(SUM(total),0) FROM contracts WHERE status='signed'")->fetchColumn();
        $stats['month_signed']  = (int)$pdo->query("SELECT COUNT(*) FROM contracts WHERE status='signed' AND MONTH(signed_at)=MONTH(NOW()) AND YEAR(signed_at)=YEAR(NOW())")->fetchColumn();
        json_out($stats);
    }

    // ══ TƏNZİMLƏMƏLƏR ═══════════════════════════
    if ($action === 'settings') {
        if ($method === 'GET') {
            json_out(ensure_settings());
        }
        if ($method === 'POST') {
            $d = body();
            $allowed = ['company_name','voen','phone','director','address','email','vat_rate','contract_terms'];
            $sets = []; $params = [];
            foreach ($allowed as $f) {
                if (array_key_exists($f,$d)) {
                    $sets[]   = "`$f`=?";
                    $params[] = $f==='vat_rate' ? (float)$d[$f] : (string)$d[$f];
                }
            }
            if ($sets) db()->prepare("UPDATE settings SET ".implode(',',$sets))->execute($params);
            json_out(ensure_settings());
        }
    }

    // ══ ŞİFRƏ DƏYİŞ ════════════════════════════
    if ($action === 'change_password' && $method === 'POST') {
        $d   = body();
        $old = $d['old_password'] ?? '';
        $new = $d['new_password'] ?? '';
        $usr = $_SESSION['apex_user'] ?? '';
        if (strlen($new) < 6) err('Yeni şifrə ən az 6 simvol olmalıdır');
        $st = db()->prepare("SELECT password FROM users WHERE username=?"); $st->execute([$usr]);
        $row = $st->fetch();
        if (!$row || !password_verify($old,$row['password'])) err('Köhnə şifrə yanlışdır');
        $hash = password_hash($new, PASSWORD_BCRYPT, ['cost'=>12]);
        db()->prepare("UPDATE users SET password=? WHERE username=?")->execute([$hash,$usr]);
        json_out(['ok'=>true,'message'=>'Şifrə uğurla dəyişdirildi']);
    }

    // ══ İMZA AL (PUBLIC) ════════════════════════
    if ($action === 'sign_get' && $token) {
        $st = db()->prepare("SELECT * FROM contracts WHERE sign_token=?"); $st->execute([$token]);
        $row = $st->fetch();
        if (!$row) err('Müqavilə tapılmadı',404);
        if ($row['status']==='cancelled') err('Bu müqavilə ləğv edilib',410);

        $settings  = ensure_settings();
        $result    = fmt_contract($row);
        $result['_company'] = [
            'name'     => $settings['company_name'],
            'voen'     => $settings['voen'],
            'phone'    => $settings['phone'],
            'director' => $settings['director'],
            'address'  => $settings['address'],
            'terms'    => $settings['contract_terms'] ?? '',
        ];
        json_out($result);
    }

    // ══ İMZALA (PUBLIC) ═════════════════════════
    if ($action === 'sign_submit' && $token && $method === 'POST') {
        $d  = body();
        $st = db()->prepare("SELECT * FROM contracts WHERE sign_token=?"); $st->execute([$token]);
        $row = $st->fetch();
        if (!$row)                          err('Tapılmadı',404);
        if ($row['status']==='signed')      err('Artıq imzalanıb',409);
        if ($row['status']==='cancelled')   err('Bu müqavilə ləğv edilib',410);
        if (empty($d['signature']))         err('İmza tələb olunur');
        $sig = $d['signature'];
        if (!preg_match('/^data:image\/(png|jpeg|jpg);base64,/',$sig)) err('Yanlış imza formatı');
        db()->prepare("UPDATE contracts SET status='signed',signature=?,signed_at=NOW() WHERE sign_token=?")
            ->execute([$sig,$token]);
        $st2 = db()->prepare("SELECT * FROM contracts WHERE sign_token=?"); $st2->execute([$token]);
        json_out(fmt_contract($st2->fetch()));
    }

    err('Yanlış sorğu',400);

} catch (PDOException $e) {
    err('DB xətası: '.$e->getMessage(),500);
} catch (Throwable $e) {
    err('Server xətası',500);
}
