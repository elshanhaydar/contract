<?php
// ══════════════════════════════════════════════
//  APEX INDUSTRIES MMC — Quraşdırma
//  install.php — bir dəfə icra edin, sonra SİLİN
// ══════════════════════════════════════════════
require_once 'config.php';

$errors  = [];
$success = [];

// Defolt müqavilə şərtləri
$defaultTerms = "1. ÜMUMI MÜDDƏALAR\n1.1. Bu müqavilə Azərbaycan Respublikasının müvafiq qanunvericiliyi əsasında bağlanır.\n1.2. Müqavilə hər iki tərəf tərəfindən imzalandıqdan sonra hüquqi qüvvəyə minir.\n\n2. TƏSLİMAT VƏ QƏBUL\n2.1. Mallar/xidmətlər razılaşdırılmış müddət ərzində təhvil verilir.\n2.2. Alıcı malları qəbul etdikdən sonra 3 iş günü ərzində iddia irəli sürə bilər.\n\n3. ÖDƏNİŞ ŞƏRTLƏRI\n3.1. Ödəniş müqavilədə göstərilən valyuta və müddətdə həyata keçirilir.\n3.2. Gecikmə halında hər gün üçün ümumi məbləğin 0.1%-i dəyərində cərimə tətbiq edilir.\n\n4. ZƏMANƏTLİ XİDMƏT\n4.1. Məhsula/xidmətə müqavilədə göstərilən müddət ərzində pulsuz texniki xidmət göstərilir.\n4.2. Zəmanət istifadəçi xətaları, mexaniki zədələr və qeyri-adi şəraitdə istifadəni əhatə etmir.\n\n5. MƏXFİLİK\n5.1. Tərəflər bir-birinin kommersiya sirrlərini üçüncü şəxslərə açıqlamamağı öhdəsinə götürür.\n\n6. MÜQAVİLƏNİN POZULMASI\n6.1. Hər hansı bir tərəf müqavilə şərtlərini pozarsa, digər tərəf 10 iş günü ərzində xəbərdar etməlidir.\n6.2. Mübahisələr danışıqlar yolu ilə, mümkün olmadıqda isə Azərbaycan məhkəmələri vasitəsilə həll edilir.\n\n7. QÜVVƏYƏ MİNMƏ\n7.1. Müqavilə hər iki tərəfin elektron və ya əl ilə imzası ilə qüvvəyə minir.\n7.2. Müqavilənin şərtlərini dəyişdirmək üçün hər iki tərəfin yazılı razılığı tələb olunur.";

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";charset=" . DB_CHARSET,
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    $pdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `" . DB_NAME . "`");
    $success[] = "Verilənlər bazası yaradıldı: " . DB_NAME;

    // ── contracts ─────────────────────────────
    $pdo->exec("CREATE TABLE IF NOT EXISTS `contracts` (
        `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `contract_no`   VARCHAR(30)   NOT NULL UNIQUE,
        `sign_token`    VARCHAR(60)   NOT NULL UNIQUE,
        `status`        ENUM('pending','sent','signed','cancelled') NOT NULL DEFAULT 'pending',
        `fname`         VARCHAR(100)  NOT NULL,
        `lname`         VARCHAR(100)  NOT NULL,
        `patronym`      VARCHAR(100)  DEFAULT NULL,
        `dob`           DATE          DEFAULT NULL,
        `idnum`         VARCHAR(50)   NOT NULL,
        `fin`           VARCHAR(20)   DEFAULT NULL,
        `idissue`       VARCHAR(50)   DEFAULT NULL,
        `idexpiry`      VARCHAR(50)   DEFAULT NULL,
        `idauth`        VARCHAR(100)  DEFAULT NULL,
        `address`       TEXT          NOT NULL,
        `delivery`      TEXT          DEFAULT NULL,
        `phone`         VARCHAR(30)   NOT NULL,
        `email`         VARCHAR(150)  DEFAULT NULL,
        `items`         LONGTEXT      NOT NULL DEFAULT ('[]'),
        `vat_included`  TINYINT(1)    NOT NULL DEFAULT 1,
        `subtotal`      DECIMAL(14,2) NOT NULL DEFAULT 0,
        `vat`           DECIMAL(14,2) NOT NULL DEFAULT 0,
        `total`         DECIMAL(14,2) NOT NULL DEFAULT 0,
        `deposit`       DECIMAL(14,2) NOT NULL DEFAULT 0,
        `remaining`     DECIMAL(14,2) NOT NULL DEFAULT 0,
        `deposit_date`  DATE          DEFAULT NULL,
        `final_date`    DATE          DEFAULT NULL,
        `pay_method`    VARCHAR(60)   NOT NULL DEFAULT 'Nağd',
        `currency`      VARCHAR(10)   NOT NULL DEFAULT 'AZN',
        `install_date`  DATE          DEFAULT NULL,
        `warranty`      VARCHAR(60)   NOT NULL DEFAULT '12 ay',
        `notes`         TEXT          DEFAULT NULL,
        `signature`     LONGTEXT      DEFAULT NULL,
        `created_at`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `sent_at`       DATETIME      DEFAULT NULL,
        `signed_at`     DATETIME      DEFAULT NULL,
        INDEX idx_status (`status`),
        INDEX idx_phone  (`phone`),
        INDEX idx_idnum  (`idnum`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $success[] = "contracts cədvəli hazırdır";

    // ── settings ──────────────────────────────
    $pdo->exec("CREATE TABLE IF NOT EXISTS `settings` (
        `id`             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `company_name`   VARCHAR(200) NOT NULL DEFAULT '" . DEFAULT_COMPANY . "',
        `voen`           VARCHAR(20)  NOT NULL DEFAULT '" . DEFAULT_VOEN . "',
        `phone`          VARCHAR(40)  NOT NULL DEFAULT '" . DEFAULT_PHONE . "',
        `director`       VARCHAR(150) NOT NULL DEFAULT '" . DEFAULT_DIRECTOR . "',
        `address`        TEXT         NOT NULL,
        `email`          VARCHAR(150) DEFAULT NULL,
        `vat_rate`       DECIMAL(5,2) NOT NULL DEFAULT " . DEFAULT_VAT . ",
        `contract_terms` LONGTEXT     DEFAULT NULL,
        `updated_at`     DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $success[] = "settings cədvəli hazırdır";

    // ── users ─────────────────────────────────
    $pdo->exec("CREATE TABLE IF NOT EXISTS `users` (
        `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `username`   VARCHAR(80)  NOT NULL UNIQUE,
        `password`   VARCHAR(255) NOT NULL,
        `name`       VARCHAR(150) DEFAULT NULL,
        `role`       ENUM('admin','operator') NOT NULL DEFAULT 'admin',
        `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $success[] = "users cədvəli hazırdır";

    // Defolt admin
    $cnt = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    if ($cnt == 0) {
        $hash = password_hash('admin123', PASSWORD_BCRYPT, ['cost' => 12]);
        $pdo->prepare("INSERT INTO users (username,password,name,role) VALUES (?,?,?,?)")
            ->execute(['admin', $hash, 'Administrator', 'admin']);
        $success[] = "Defolt admin yaradıldı: admin / admin123";
    }

    // Defolt ayarlar + müqavilə şərtləri
    $cnt2 = $pdo->query("SELECT COUNT(*) FROM settings")->fetchColumn();
    if ($cnt2 == 0) {
        $stmt = $pdo->prepare("INSERT INTO settings (company_name,voen,phone,director,address,vat_rate,contract_terms) VALUES (?,?,?,?,?,?,?)");
        $stmt->execute([DEFAULT_COMPANY, DEFAULT_VOEN, DEFAULT_PHONE, DEFAULT_DIRECTOR, DEFAULT_ADDRESS, DEFAULT_VAT, $defaultTerms]);
        $success[] = "Defolt tənzimləmə və müqavilə şərtləri yaradıldı";
    }

    // Mövcud DB-yə contract_terms əlavə et
    try {
        $pdo->exec("ALTER TABLE settings ADD COLUMN contract_terms LONGTEXT DEFAULT NULL");
        // Boşdursa defolt şərtləri yaz
        $pdo->prepare("UPDATE settings SET contract_terms = ? WHERE contract_terms IS NULL")->execute([$defaultTerms]);
        $success[] = "contract_terms sütunu əlavə edildi";
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'Duplicate column') !== false) {
            $success[] = "contract_terms sütunu artıq mövcuddur";
        } else { throw $e; }
    }

} catch (PDOException $e) {
    $errors[] = "DB Xətası: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="az">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Apex — Quraşdırma</title>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Outfit',sans-serif;background:#0b1628;color:#fff;display:flex;align-items:center;justify-content:center;min-height:100vh}
.box{background:#152340;border-radius:16px;padding:40px;max-width:600px;width:100%;box-shadow:0 20px 60px rgba(0,0,0,.4);margin:20px}
h1{font-size:24px;margin-bottom:4px;color:#f0a832}
.sub{font-size:13px;color:rgba(255,255,255,.4);margin-bottom:28px}
.item{padding:10px 14px;border-radius:8px;margin-bottom:8px;font-size:13.5px;display:flex;gap:10px;align-items:flex-start}
.ok{background:rgba(5,150,105,.2);border:1px solid rgba(5,150,105,.4);color:#6ee7b7}
.er{background:rgba(185,28,28,.2);border:1px solid rgba(185,28,28,.4);color:#fca5a5}
.warn{background:rgba(212,136,10,.12);border:1px solid rgba(212,136,10,.4);color:#fcd34d;margin-top:20px;border-radius:10px;padding:16px 20px;font-size:13px;line-height:1.8}
.warn strong{color:#f0a832}
a.btn{display:inline-block;margin-top:20px;background:linear-gradient(135deg,#d4880a,#f0a832);color:#0b1628;padding:13px 32px;border-radius:10px;text-decoration:none;font-weight:700;font-size:14px}
</style>
</head>
<body>
<div class="box">
  <h1>⚙️ Apex Industries — Quraşdırma</h1>
  <div class="sub">Verilənlər bazası avtomatik konfiqurasiya edilir</div>
  <?php foreach($success as $msg): ?>
    <div class="item ok">✓ <?= htmlspecialchars($msg) ?></div>
  <?php endforeach; ?>
  <?php foreach($errors as $msg): ?>
    <div class="item er">✕ <?= htmlspecialchars($msg) ?></div>
  <?php endforeach; ?>
  <?php if (empty($errors)): ?>
    <div class="warn">
      ⚠️ <strong>Vacib:</strong> Quraşdırma tamamlandı.<br>
      Defolt giriş: <strong>admin</strong> / <strong>admin123</strong><br>
      Müqavilə şərtlərini <strong>Admin → Tənzimləmələr</strong> bölməsindən redaktə edə bilərsiniz.<br>
      Təhlükəsizlik üçün <strong>install.php</strong> faylını serverinizdən <strong>dərhal silin</strong>.
    </div>
    <a href="login.php" class="btn">→ Giriş Səhifəsinə Keç</a>
  <?php else: ?>
    <div class="warn">config.php faylında DB məlumatlarını yoxlayın və yenidən cəhd edin.</div>
  <?php endif; ?>
</div>
</body>
</html>
