<?php
// ── HELPER FUNKSİYALAR ────────────────────────

function json_out($data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}

function err(string $msg, int $code = 400): void {
    json_out(['error' => $msg], $code);
}

function body(): array {
    $raw = file_get_contents('php://input');
    return json_decode($raw ?: '{}', true) ?? [];
}

function s(string $v): string {
    return htmlspecialchars(strip_tags(trim($v)), ENT_QUOTES, 'UTF-8');
}

function gen_contract_no(): string {
    return 'APX-' . date('Y') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
}

function gen_token(): string {
    return bin2hex(random_bytes(24));
}

function ensure_unique_no(): string {
    $tries = 0;
    do {
        $no   = gen_contract_no();
        $tries++;
        $st   = db()->prepare("SELECT id FROM contracts WHERE contract_no = ?");
        $st->execute([$no]);
    } while ($st->fetchColumn() && $tries < 50);
    return $no;
}

function fmt_contract(array $c): array {
    $c['items']        = json_decode($c['items'] ?? '[]', true) ?? [];
    $c['vat_included'] = (bool)($c['vat_included'] ?? 1);
    $c['subtotal']     = (float)$c['subtotal'];
    $c['vat']          = (float)$c['vat'];
    $c['total']        = (float)$c['total'];
    $c['deposit']      = (float)$c['deposit'];
    $c['remaining']    = (float)$c['remaining'];
    return $c;
}

function ensure_settings(): array {
    $pdo = db();

    // contract_terms sütunu mövcuddurmu?
    try {
        $pdo->query("SELECT contract_terms FROM settings LIMIT 1");
    } catch (PDOException $e) {
        $pdo->exec("ALTER TABLE settings ADD COLUMN contract_terms LONGTEXT DEFAULT NULL AFTER vat_rate");
    }

    $row = $pdo->query("SELECT * FROM settings LIMIT 1")->fetch();
    if (!$row) {
        $pdo->exec("INSERT INTO settings (company_name,voen,phone,director,address,vat_rate,contract_terms) VALUES
            ('" . DEFAULT_COMPANY . "','" . DEFAULT_VOEN . "','" . DEFAULT_PHONE . "',
             '" . DEFAULT_DIRECTOR . "','" . DEFAULT_ADDRESS . "'," . DEFAULT_VAT . ", NULL)");
        $row = $pdo->query("SELECT * FROM settings LIMIT 1")->fetch();
    }
    $row['vat_rate']       = (float)$row['vat_rate'];
    $row['contract_terms'] = $row['contract_terms'] ?? '';
    return $row;
}

function fmt_money(float $amount, string $currency = 'AZN'): string {
    return number_format($amount, 2, '.', ' ') . ' ' . $currency;
}

function fmt_date(?string $date): string {
    if (!$date) return '—';
    try { return (new DateTime($date))->format('d.m.Y'); }
    catch (Exception $e) { return $date; }
}

function status_label(string $status): array {
    return match($status) {
        'pending'   => ['Gözləyir',    'badge-pending'],
        'sent'      => ['Göndərilib',  'badge-sent'],
        'signed'    => ['İmzalandı',   'badge-signed'],
        'cancelled' => ['Ləğv edildi', 'badge-cancelled'],
        default     => [$status, 'badge-pending'],
    };
}
