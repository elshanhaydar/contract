<?php
// ── AUTENTİFİKASİYA HELPERLƏRİ ────────────────

function is_logged_in(): bool {
    return !empty($_SESSION['apex_admin']);
}

function require_login(): void {
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

function login_attempt(string $user, string $pass): bool {
    if ($user !== ADMIN_USER) return false;
    // Əgər şifrə hələ hash edilməyibsə (install zamanı)
    if (ADMIN_PASS === '$2y$12$YourHashedPasswordHere') {
        // İlk dəfə: plain text müqayisə yalnız quraşdırma üçün
        return $pass === 'admin123';
    }
    return password_verify($pass, ADMIN_PASS);
}

function do_login(): void {
    $_SESSION['apex_admin'] = true;
    $_SESSION['apex_user']  = ADMIN_USER;
    $_SESSION['apex_time']  = time();
    session_regenerate_id(true);
}

function do_logout(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path']);
    }
    session_destroy();
}
