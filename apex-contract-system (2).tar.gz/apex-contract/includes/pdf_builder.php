<?php
// ══════════════════════════════════════════════
//  APEX — PDF Builder v2 (TCPDF)
//  includes/pdf_builder.php
//  Simmetrik, peşəkar A4 müqavilə formatı
// ══════════════════════════════════════════════

require_once __DIR__ . '/../tcpdf/tcpdf.php';

// ── Rənglər ──────────────────────────────────
define('C_NAVY_R',   11);  define('C_NAVY_G',   22);  define('C_NAVY_B',   40);
define('C_AMBER_R', 212);  define('C_AMBER_G', 136);  define('C_AMBER_B',  10);
define('C_AMLT_R',  240);  define('C_AMLT_G',  168);  define('C_AMLT_B',   50);
define('C_OFFWH_R', 246);  define('C_OFFWH_G', 248);  define('C_OFFWH_B', 252);
define('C_BORDER_R',221);  define('C_BORDER_G',227);  define('C_BORDER_B',238);
define('C_SOFT_R',   74);  define('C_SOFT_G',   85);  define('C_SOFT_B',  104);
define('C_LIGHT_R', 138);  define('C_LIGHT_G', 153);  define('C_LIGHT_B', 176);
define('C_SUCC_R',   13);  define('C_SUCC_G',  110);  define('C_SUCC_B',   79);

// ── Ana funksiya ─────────────────────────────
function build_contract_pdf(array $c, array $company): string
{
    $pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);
    $pdf->SetCreator(APP_NAME);
    $pdf->SetAuthor($company['company_name']);
    $pdf->SetTitle('Müqavilə ' . $c['contract_no']);
    $pdf->SetSubject('Satış Müqaviləsi');
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);
    $pdf->SetMargins(16, 16, 16);
    $pdf->SetAutoPageBreak(true, 20);
    $pdf->SetFont('dejavusans', '', 9);
    $pdf->AddPage();

    $fb = 'dejavusans'; // bold => SetFont($fb,'B',...)
    $fr = 'dejavusans'; // regular

    // ══════════════════════════════════════════
    //  BAŞLIQ BÖLMƏSİ
    // ══════════════════════════════════════════
    _pdf_header($pdf, $fb, $fr, $c, $company);

    // ══════════════════════════════════════════
    //  §1 — TƏRƏFLƏR (SİMMETRİK YAN-YANA)
    // ══════════════════════════════════════════
    _pdf_section_bar($pdf, $fb, '§1 — MÜQAVİLƏNİN TƏRƏFLƏRİ');

    $pY = $pdf->GetY() + 2;

    $sellerRows = [
        ['Şirkətin adı',  $company['company_name']],
        ['VÖEN',          $company['voen']],
        ['Direktor',      $company['director']],
        ['Telefon',       $company['phone']],
        ['Ünvan',         $company['address']],
    ];
    $buyerRows = [
        ['Ad, Soyad',    trim($c['fname'].' '.$c['lname'].' '.($c['patronym']??''))],
        ['Ş/V Seriya №', $c['idnum'] ?? '—'],
        ['FİN kodu',     $c['fin']   ?? '—'],
    ];

    $colW = 88; $gap = 4; $lX = 16; $rX = 16 + $colW + $gap;

    $lH = _pdf_party_box($pdf, $fb, $fr, $lX, $pY, $colW, 'SATICI', $sellerRows);
    $rH = _pdf_party_box($pdf, $fb, $fr, $rX, $pY, $colW, 'ALICI (MÜŞTƏRİ)', $buyerRows);

    $pdf->SetY($pY + max($lH, $rH) + 6);

    // ══════════════════════════════════════════
    //  §2 — MALLARIN SİYAHISI
    // ══════════════════════════════════════════
    _pdf_section_bar($pdf, $fb, '§2 — MALLARIN / XİDMƏTLƏRİN SİYAHISI');
    _pdf_items_table($pdf, $fb, $fr, $c);

    // ══════════════════════════════════════════
    //  §3 — ÖDƏNİŞ ŞƏRTLƏRI (SİMMETRİK)
    // ══════════════════════════════════════════
    $pdf->Ln(4);
    _pdf_section_bar($pdf, $fb, '§3 — ÖDƏNİŞ ŞƏRTLƏRI');

    $payLeft = [
        ['Ödəniş üsulu',   $c['pay_method'] ?? 'Nağd'],
        ['Valyuta',        $c['currency'] ?? 'AZN'],
        ['İlkin ödəniş',   fmt_money($c['deposit'], $c['currency'] ?? 'AZN')],
        ['Qalan məbləğ',   fmt_money($c['remaining'], $c['currency'] ?? 'AZN')],
    ];
    $payRight = [
        ['İlkin ödəniş tarixi', fmt_date($c['deposit_date'])],
        ['Yekun ödəniş tarixi', fmt_date($c['final_date'])],
        ['Quraşdırma tarixi',   fmt_date($c['install_date'])],
        ['Zəmanət müddəti',     $c['warranty'] ?? '12 ay'],
    ];

    $pyY = $pdf->GetY() + 2;
    _pdf_kv_box($pdf, $fb, $fr, $lX, $pyY, $colW, $payLeft);
    _pdf_kv_box($pdf, $fb, $fr, $rX, $pyY, $colW, $payRight);
    $pdf->SetY($pyY + count($payLeft) * 7 + 6);

    // ══════════════════════════════════════════
    //  §4 — MÜQAVİLƏ ŞƏRTLƏRİ (əgər varsa)
    // ══════════════════════════════════════════
    $terms = $company['contract_terms'] ?? '';
    if ($terms) {
        $pdf->Ln(2);
        _pdf_section_bar($pdf, $fb, '§4 — MÜQAVİLƏ ŞƏRTLƏRİ VƏ ÖHDƏLIKLƏR');
        $pdf->SetFont($fr, '', 8.2);
        _pdf_set_color($pdf, 'text', C_SOFT_R, C_SOFT_G, C_SOFT_B);
        $pdf->SetX(16);
        $pdf->MultiCell(178, 4.8, $terms, 0, 'L', false, 1);
        $pdf->Ln(4);
    }

    // ══════════════════════════════════════════
    //  §5 — QEYDLƏR
    // ══════════════════════════════════════════
    if (!empty($c['notes'])) {
        $sec = $terms ? '§5' : '§4';
        _pdf_section_bar($pdf, $fb, $sec . ' — ƏLAVƏ QEYDLƏR');
        $pdf->SetFont($fr, '', 8.5);
        _pdf_set_color($pdf, 'text', C_SOFT_R, C_SOFT_G, C_SOFT_B);
        $pdf->SetX(16);
        $pdf->MultiCell(178, 5, $c['notes'], 0, 'L');
        $pdf->Ln(4);
    }

    // ══════════════════════════════════════════
    //  İMZA BÖLMƏSİ — SİMMETRİK, YAN-YANA
    // ══════════════════════════════════════════
    // Yeni səhifəyə keç əgər yer az qalıbsa
    if ($pdf->GetY() > 230) $pdf->AddPage();
    else $pdf->Ln(4);

    $lastSec = '§' . (($terms ? 5 : 4) + (empty($c['notes']) ? 0 : 1));
    _pdf_section_bar($pdf, $fb, $lastSec . ' — TƏRƏFLƏRİN İMZASI VƏ MÖHÜR');

    $sigY  = $pdf->GetY() + 2;
    $sigW  = 88;
    $sigH  = 52;

    _pdf_sig_box($pdf, $fb, $fr, $lX, $sigY, $sigW, $sigH,
        'SATICI',
        $company['company_name'],
        $company['director'],
        null
    );

    _pdf_sig_box($pdf, $fb, $fr, $rX, $sigY, $sigW, $sigH,
        'ALICI',
        trim($c['fname'] . ' ' . $c['lname']),
        !empty($c['signed_at']) ? 'İmzalanma tarixi: ' . fmt_date(substr($c['signed_at'], 0, 10)) : 'İmzalanma tarixi: —',
        $c['signature'] ?? null
    );

    $pdf->SetY($sigY + $sigH + 4);

    // ══════════════════════════════════════════
    //  SƏHİFƏ NÖMRƏSI — ALT BAŞLIQ
    // ══════════════════════════════════════════
    _pdf_page_footer($pdf, $fr, $c, $company);

    return $pdf->Output('', 'S');
}


// ══════════════════════════════════════════════
//  BAŞLIQ BÖLMƏSİ
// ══════════════════════════════════════════════
function _pdf_header(TCPDF $pdf, string $fb, string $fr, array $c, array $company): void
{
    $pageW = 210;

    // Arxa fon — tünd
    $pdf->SetFillColor(C_NAVY_R, C_NAVY_G, C_NAVY_B);
    $pdf->Rect(0, 0, $pageW, 46, 'F');

    // Dekorativ amber şerid — sağ alt
    $pdf->SetFillColor(C_AMBER_R, C_AMBER_G, C_AMBER_B);
    $pdf->Rect($pageW - 6, 0, 6, 46, 'F');

    // Şirkət adı
    $pdf->SetFont($fb, 'B', 20);
    $pdf->SetTextColor(C_AMLT_R, C_AMLT_G, C_AMLT_B);
    $pdf->SetXY(16, 8);
    $pdf->Cell(120, 10, $company['company_name'], 0, 1, 'L');

    // Şirkət alt məlumatları
    $pdf->SetFont($fr, '', 8.5);
    $pdf->SetTextColor(180, 195, 220);
    $pdf->SetXY(16, 20);
    $pdf->Cell(120, 5, 'VÖEN: '.$company['voen'].'   |   Tel: '.$company['phone'], 0, 1, 'L');
    $pdf->SetXY(16, 26);
    $pdf->Cell(120, 5, $company['address'], 0, 1, 'L');

    // Sağ tərəf — Müqavilə mövzusu
    $pdf->SetFont($fb, 'B', 9);
    $pdf->SetTextColor(C_AMLT_R, C_AMLT_G, C_AMLT_B);
    $pdf->SetXY(130, 8);
    $pdf->Cell(72, 6, 'SATIŞ MÜQAVİLƏSİ', 0, 1, 'R');

    $pdf->SetFont($fb, 'B', 16);
    $pdf->SetXY(130, 15);
    $pdf->Cell(72, 8, $c['contract_no'], 0, 1, 'R');

    $pdf->SetFont($fr, '', 8);
    $pdf->SetTextColor(160, 180, 210);
    $pdf->SetXY(130, 25);
    $pdf->Cell(72, 5, 'Tarix: '.fmt_date(substr($c['created_at']??date('Y-m-d'),0,10)), 0, 1, 'R');

    // Status badge
    $statusColors = [
        'signed'    => [C_SUCC_R, C_SUCC_G, C_SUCC_B, 'İMZALANMIŞ'],
        'sent'      => [41, 98, 255, 41, 98, 255, 'GÖNDƏRİLMİŞ'],
        'pending'   => [C_AMBER_R, C_AMBER_G, C_AMBER_B, 'GÖZLƏYİR'],
        'cancelled' => [185, 28, 28, 'LƏğV EDİLMİŞ'],
    ];
    $st   = $c['status'] ?? 'pending';
    $stL  = ['signed'=>'İMZALANMIŞ','sent'=>'GÖNDƏRİLMİŞ','pending'=>'GÖZLƏYİR','cancelled'=>'LƏğV EDİLMİŞ'][$st] ?? strtoupper($st);
    $stRGB= ['signed'=>[C_SUCC_R,C_SUCC_G,C_SUCC_B],'sent'=>[41,98,255],'pending'=>[C_AMBER_R,C_AMBER_G,C_AMBER_B],'cancelled'=>[185,28,28]][$st] ?? [C_AMBER_R,C_AMBER_G,C_AMBER_B];
    $pdf->SetFont($fb, 'B', 7.5);
    $pdf->SetFillColor($stRGB[0], $stRGB[1], $stRGB[2]);
    $pdf->SetTextColor(255, 255, 255);
    $pdf->SetXY(158, 31.5);
    $pdf->Cell(44, 6, $stL, 0, 1, 'C', true);

    $pdf->SetY(52);
    $pdf->SetTextColor(C_NAVY_R, C_NAVY_G, C_NAVY_B);
}


// ══════════════════════════════════════════════
//  BÖLMƏ BAŞLIĞI
// ══════════════════════════════════════════════
function _pdf_section_bar(TCPDF $pdf, string $fb, string $title): void
{
    $pdf->SetFont($fb, 'B', 8.5);
    $pdf->SetFillColor(C_NAVY_R, C_NAVY_G, C_NAVY_B);
    $pdf->SetTextColor(C_AMLT_R, C_AMLT_G, C_AMLT_B);
    $pdf->SetX(16);
    $pdf->Cell(178, 7, '  ' . $title, 0, 1, 'L', true);
    $pdf->SetFillColor(C_AMBER_R, C_AMBER_G, C_AMBER_B);
    $pdf->Rect(16, $pdf->GetY(), 178, 0.6, 'F');
    $pdf->Ln(4);
    $pdf->SetTextColor(C_NAVY_R, C_NAVY_G, C_NAVY_B);
}


// ══════════════════════════════════════════════
//  TƏRƏF QUTUSU (SİMMETRİK)
// ══════════════════════════════════════════════
function _pdf_party_box(TCPDF $pdf, string $fb, string $fr, float $x, float $y, float $w, string $heading, array $rows): float
{
    $lineH  = 6.5;
    $headH  = 8;
    $padTop = 3;
    $padBot = 3;
    $boxH   = $headH + $padTop + count($rows) * $lineH + $padBot;

    // Kölgə efekti (açıq rəng)
    $pdf->SetFillColor(C_OFFWH_R, C_OFFWH_G, C_OFFWH_B);
    $pdf->SetDrawColor(C_BORDER_R, C_BORDER_G, C_BORDER_B);
    $pdf->SetLineWidth(0.25);
    $pdf->RoundedRect($x, $y, $w, $boxH, 2, '1111', 'DF');

    // Başlıq şeridi
    $pdf->SetFillColor(C_NAVY_R, C_NAVY_G, C_NAVY_B);
    $pdf->RoundedRect($x, $y, $w, $headH, 2, '1100', 'F');
    $pdf->SetFont($fb, 'B', 8.5);
    $pdf->SetTextColor(C_AMLT_R, C_AMLT_G, C_AMLT_B);
    $pdf->SetXY($x + 4, $y + 1.5);
    $pdf->Cell($w - 8, $headH - 2, $heading, 0, 1, 'L');

    // Sətrlər
    $cy = $y + $headH + $padTop;
    foreach ($rows as [$label, $val]) {
        $val = trim((string)($val ?? ''));
        if ($val === '') $val = '—';

        // Label
        $pdf->SetFont($fr, '', 7.5);
        $pdf->SetTextColor(C_LIGHT_R, C_LIGHT_G, C_LIGHT_B);
        $pdf->SetXY($x + 3, $cy);
        $pdf->Cell(30, $lineH, $label . ':', 0, 0, 'L');

        // Dəyər
        $pdf->SetFont($fb, 'B', 8);
        $pdf->SetTextColor(C_NAVY_R, C_NAVY_G, C_NAVY_B);
        $pdf->SetXY($x + 34, $cy);
        // Uzun mətn üçün daralt — shortenedText() TCPDF-də yoxdur, özümüz edik
        $pdf->Cell($w - 37, $lineH, _pdf_shorten($pdf, $val, $w - 37), 0, 0, 'L');

        // Ayırıcı xətt (son sətir xaric)
        if ($val !== end(array_column($rows, 1))) {
            $pdf->SetDrawColor(C_BORDER_R, C_BORDER_G, C_BORDER_B);
            $pdf->SetLineWidth(0.15);
            $pdf->Line($x + 3, $cy + $lineH, $x + $w - 3, $cy + $lineH);
        }
        $cy += $lineH;
    }

    $pdf->SetY($y + $boxH);
    return $boxH;
}


// ══════════════════════════════════════════════
//  MALLAR CƏDVƏLİ
// ══════════════════════════════════════════════
function _pdf_items_table(TCPDF $pdf, string $fb, string $fr, array $c): void
{
    $items = $c['items'] ?? [];

    // Cədvəl başlıqları
    $cols  = [8, 76, 14, 20, 30, 30]; // %, mm
    $heads = ['№', 'Məhsul / Xidmət', 'Vahid', 'Miqdar', 'Qiymət', 'Cəm'];
    $alH   = ['C','L','C','C','R','R'];

    $pdf->SetFont($fb, 'B', 8);
    $pdf->SetFillColor(C_NAVY_R, C_NAVY_G, C_NAVY_B);
    $pdf->SetTextColor(200, 215, 235);
    $pdf->SetX(16);
    foreach ($cols as $i => $cw) {
        $pdf->Cell($cw, 7.5, $heads[$i], 0, 0, $alH[$i], true);
    }
    $pdf->Ln(7.5);

    if (!$items) {
        $pdf->SetFont($fr, '', 8.5);
        $pdf->SetTextColor(C_LIGHT_R, C_LIGHT_G, C_LIGHT_B);
        $pdf->SetX(16);
        $pdf->Cell(178, 8, 'Mal / xidmət siyahısı boşdur.', 0, 1, 'C');
    } else {
        $rowH = 6.5;
        $fill = false;
        foreach ($items as $i => $item) {
            $qty      = (float)($item['qty']   ?? 1);
            $price    = (float)($item['price'] ?? 0);
            $subtotal = $qty * $price;

            $pdf->SetFont($fr, '', 8.2);
            $pdf->SetTextColor(C_NAVY_R, C_NAVY_G, C_NAVY_B);
            $pdf->SetFillColor($fill ? 243 : 255, $fill ? 245 : 255, $fill ? 251 : 255);

            $vals = [
                $i + 1,
                $item['name'] ?? '',
                $item['unit'] ?? 'əd',
                number_format($qty, 0),
                number_format($price, 2, '.', ' '),
                number_format($subtotal, 2, '.', ' '),
            ];
            $pdf->SetX(16);
            foreach ($cols as $j => $cw) {
                $pdf->Cell($cw, $rowH, $vals[$j], 'B', 0, $alH[$j], true);
            }
            $pdf->Ln($rowH);
            $fill = !$fill;
        }
    }

    // CƏMLƏr — 3 sıra, sağda blok
    $pdf->Ln(2);
    $labelW = 34;
    $valW   = 28;
    $startX = 16 + 178 - $labelW - $valW;

    $totRows = [
        ['Ara cəm:',  fmt_money($c['subtotal'], $c['currency'] ?? 'AZN'), false, false],
        ['ƏDV ('.($c['vat_included']?'18%':'0%').'):', fmt_money($c['vat'], $c['currency'] ?? 'AZN'), false, false],
        ['YEKUN:', fmt_money($c['total'], $c['currency'] ?? 'AZN'), true, true],
    ];

    foreach ($totRows as [$lbl, $val, $bold, $highlight]) {
        if ($highlight) {
            $pdf->SetFillColor(C_AMBER_R, C_AMBER_G, C_AMBER_B);
            $pdf->SetTextColor(255, 255, 255);
            $h = 9;
        } else {
            $pdf->SetFillColor(C_OFFWH_R, C_OFFWH_G, C_OFFWH_B);
            $pdf->SetTextColor(C_SOFT_R, C_SOFT_G, C_SOFT_B);
            $h = 7;
        }
        $pdf->SetFont($fb, $bold ? 'B' : '', $bold ? 10 : 8.5);
        $pdf->SetX($startX);
        $pdf->Cell($labelW, $h, $lbl, 0, 0, 'R', true);
        $pdf->Cell($valW,   $h, $val, 0, 1, 'R', true);
    }
}


// ══════════════════════════════════════════════
//  KV QUTUSU (ödəniş şərtləri üçün)
// ══════════════════════════════════════════════
function _pdf_kv_box(TCPDF $pdf, string $fb, string $fr, float $x, float $y, float $w, array $rows): void
{
    $lh = 7;
    $boxH = count($rows) * $lh + 4;

    $pdf->SetFillColor(C_OFFWH_R, C_OFFWH_G, C_OFFWH_B);
    $pdf->SetDrawColor(C_BORDER_R, C_BORDER_G, C_BORDER_B);
    $pdf->SetLineWidth(0.25);
    $pdf->RoundedRect($x, $y, $w, $boxH, 2, '1111', 'DF');

    $cy = $y + 2;
    foreach ($rows as [$label, $val]) {
        $val = (string)($val ?? '—');
        if (trim($val) === '') $val = '—';

        $pdf->SetFont($fr, '', 7.5);
        $pdf->SetTextColor(C_LIGHT_R, C_LIGHT_G, C_LIGHT_B);
        $pdf->SetXY($x + 3, $cy);
        $pdf->Cell(36, $lh, $label . ':', 0, 0, 'L');

        $pdf->SetFont($fb, 'B', 8);
        $pdf->SetTextColor(C_NAVY_R, C_NAVY_G, C_NAVY_B);
        $pdf->SetXY($x + 40, $cy);
        $pdf->Cell($w - 43, $lh, $val, 0, 0, 'L');

        if ($cy < $y + $boxH - $lh - 2) {
            $pdf->SetDrawColor(C_BORDER_R, C_BORDER_G, C_BORDER_B);
            $pdf->SetLineWidth(0.15);
            $pdf->Line($x + 3, $cy + $lh, $x + $w - 3, $cy + $lh);
        }
        $cy += $lh;
    }
}


// ══════════════════════════════════════════════
//  İMZA QUTUSU (SİMMETRİK)
// ══════════════════════════════════════════════
function _pdf_sig_box(TCPDF $pdf, string $fb, string $fr, float $x, float $y, float $w, float $h, string $heading, string $name, string $sub, ?string $sigDataUrl): void
{
    // Çərçivə
    $pdf->SetFillColor(C_OFFWH_R, C_OFFWH_G, C_OFFWH_B);
    $pdf->SetDrawColor(C_BORDER_R, C_BORDER_G, C_BORDER_B);
    $pdf->SetLineWidth(0.3);
    $pdf->RoundedRect($x, $y, $w, $h, 2.5, '1111', 'DF');

    // Başlıq
    $pdf->SetFillColor(C_NAVY_R, C_NAVY_G, C_NAVY_B);
    $pdf->RoundedRect($x, $y, $w, 8, 2.5, '1100', 'F');
    $pdf->SetFont($fb, 'B', 8.5);
    $pdf->SetTextColor(C_AMLT_R, C_AMLT_G, C_AMLT_B);
    $pdf->SetXY($x + 4, $y + 1.5);
    $pdf->Cell($w - 8, 6, $heading, 0, 1, 'L');

    // Ad
    $pdf->SetFont($fb, 'B', 9);
    $pdf->SetTextColor(C_NAVY_R, C_NAVY_G, C_NAVY_B);
    $pdf->SetXY($x + 3, $y + 10);
    $pdf->Cell($w - 6, 6, $name, 0, 1, 'L');

    // Alt məlumat
    $pdf->SetFont($fr, '', 7.5);
    $pdf->SetTextColor(C_LIGHT_R, C_LIGHT_G, C_LIGHT_B);
    $pdf->SetXY($x + 3, $y + 17);
    $pdf->Cell($w - 6, 5, $sub, 0, 1, 'L');

    // İmza sahəsi
    $imgX = $x + 4;
    $imgY = $y + 23;
    $imgW = $w - 8;
    $imgH = $h - 27;

    if ($sigDataUrl && preg_match('/^data:image\/(png|jpeg|jpg);base64,(.+)$/s', $sigDataUrl, $m)) {
        // Müştəri imzası — base64-dən şəkil
        $imgData = base64_decode($m[2]);
        $ext     = strtolower($m[1]) === 'png' ? 'PNG' : 'JPEG';
        $tmpFile = tempnam(sys_get_temp_dir(), 'apex_sig_') . '.' . strtolower($ext);
        file_put_contents($tmpFile, $imgData);
        try {
            $pdf->Image($tmpFile, $imgX, $imgY, $imgW, $imgH, $ext, '', '', false, 150, '', false, false, 0, 'CM');
        } catch (Exception $e) { /* şəkil xətası — boş burax */ }
        @unlink($tmpFile);

        // İmzalanma tarixi
        $pdf->SetFont($fr, '', 7);
        $pdf->SetTextColor(C_SUCC_R, C_SUCC_G, C_SUCC_B);
        $pdf->SetXY($imgX, $imgY + $imgH + 1);
        $pdf->Cell($imgW, 4, '✓ Elektron imza ilə təsdiqlənib', 0, 1, 'C');
    } else {
        // Boş imza sahəsi — şirkət tərəfi
        $pdf->SetFillColor(250, 251, 254);
        $pdf->SetDrawColor(C_BORDER_R, C_BORDER_G, C_BORDER_B);
        $pdf->Rect($imgX, $imgY, $imgW, $imgH, 'DF');

        $pdf->SetFont($fr, '', 7);
        $pdf->SetTextColor(C_LIGHT_R, C_LIGHT_G, C_LIGHT_B);
        $pdf->SetXY($imgX, $imgY + $imgH / 2 - 3);
        $pdf->Cell($imgW, 5, 'Möhür / İmza', 0, 1, 'C');

        // İmza xətti
        $lineY = $imgY + $imgH - 3;
        $pdf->SetDrawColor(C_AMBER_R, C_AMBER_G, C_AMBER_B);
        $pdf->SetLineWidth(0.5);
        $pdf->Line($imgX + 4, $lineY, $imgX + $imgW - 4, $lineY);
    }
}


// ══════════════════════════════════════════════
//  ALT BAŞLIQ (Hər səhifə alt qismi)
// ══════════════════════════════════════════════
function _pdf_page_footer(TCPDF $pdf, string $fr, array $c, array $company): void
{
    $pageH = 297;
    $fY    = $pageH - 14;

    $pdf->SetFillColor(C_NAVY_R, C_NAVY_G, C_NAVY_B);
    $pdf->Rect(0, $fY, 210, 14, 'F');

    // Sol — şirkət
    $pdf->SetFont($fr, '', 7);
    $pdf->SetTextColor(140, 155, 176);
    $pdf->SetXY(16, $fY + 2);
    $pdf->Cell(90, 5, $company['company_name'] . '  |  VÖEN: ' . $company['voen'], 0, 1, 'L');
    $pdf->SetXY(16, $fY + 7);
    $pdf->Cell(90, 5, $company['phone'] . '  |  ' . $company['address'], 0, 1, 'L');

    // Sağ — müqavilə №
    $pdf->SetFont($fr, '', 7);
    $pdf->SetTextColor(C_AMLT_R, C_AMLT_G, C_AMLT_B);
    $pdf->SetXY(106, $fY + 2);
    $pdf->Cell(88, 5, 'Müqavilə №: ' . $c['contract_no'], 0, 1, 'R');
    $pdf->SetTextColor(140, 155, 176);
    $pdf->SetXY(106, $fY + 7);
    $pdf->Cell(88, 5, 'Bu sənəd elektron imza ilə qüvvəyə minir · Apex Industries MMC © ' . date('Y'), 0, 1, 'R');
}


// ── Köməkçi ──────────────────────────────────
function _pdf_set_color(TCPDF $pdf, string $type, int $r, int $g, int $b): void {
    if ($type === 'fill') $pdf->SetFillColor($r, $g, $b);
    elseif ($type === 'draw') $pdf->SetDrawColor($r, $g, $b);
    else $pdf->SetTextColor($r, $g, $b);
}

/**
 * Mətni maksimum genişliyə sığdırır, uzunsa "..." əlavə edir.
 * TCPDF-nin shortenedText() metodu mövcud deyil — bu funksiya onu əvəz edir.
 */
function _pdf_shorten(TCPDF $pdf, string $text, float $maxMm): string {
    if ($pdf->GetStringWidth($text) <= $maxMm) return $text;
    $suffix = '...';
    // Sondan bir-bir simvol sil ta ki yerləşsin
    while (mb_strlen($text, 'UTF-8') > 0) {
        $text = mb_substr($text, 0, mb_strlen($text, 'UTF-8') - 1, 'UTF-8');
        if ($pdf->GetStringWidth($text . $suffix) <= $maxMm) {
            return $text . $suffix;
        }
    }
    return $suffix;
}

