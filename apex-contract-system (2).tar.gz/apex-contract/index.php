<?php
// ══════════════════════════════════════════════
//  APEX INDUSTRIES MMC — Admin Panel v2
//  index.php
// ══════════════════════════════════════════════
require_once 'config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';
require_once 'includes/helpers.php';
require_login();

$userName = $_SESSION['apex_name'] ?? $_SESSION['apex_user'] ?? 'Admin';
$userRole = $_SESSION['apex_role'] ?? 'admin';
?>
<!DOCTYPE html>
<html lang="az">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Apex Industries MMC — Admin Panel</title>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600;700&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/admin.css">
<style>
.terms-editor{width:100%;min-height:280px;resize:vertical;padding:14px;border:1.5px solid var(--border);border-radius:8px;font-family:var(--font-body);font-size:13px;color:var(--text);line-height:1.7;outline:none;transition:border-color .18s}
.terms-editor:focus{border-color:var(--amber);box-shadow:0 0 0 3px rgba(212,136,10,.1)}
.terms-hint{font-size:11.5px;color:var(--text-light);margin-top:6px;line-height:1.6}
.terms-preview-box{background:#fffdf6;border:1px solid rgba(212,136,10,.3);border-radius:10px;padding:16px 20px;font-size:13px;color:var(--text-soft);line-height:1.85;white-space:pre-wrap;max-height:280px;overflow-y:auto;margin-top:12px;display:none}
</style>
</head>
<body>

<!-- SIDEBAR -->
<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-logo">
      <div class="brand-emblem">A</div>
      <div>
        <div class="brand-name">Apex Industries</div>
        <div class="brand-sub">MMC</div>
      </div>
    </div>
    <div class="brand-voen" id="sidebarVoen">VÖEN: —</div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-label">Əsas</div>
    <div class="nav-item active" data-page="dashboard">
      <span class="nav-icon">📊</span> İdarə Paneli
    </div>
    <div class="nav-item" data-page="contracts">
      <span class="nav-icon">📋</span> Müqavilələr
      <span class="nav-badge" id="navBadgePending">0</span>
    </div>
    <div class="nav-label">Əməliyyatlar</div>
    <div class="nav-item" data-page="new" id="btnNewContract">
      <span class="nav-icon">➕</span> Yeni Müqavilə
    </div>
    <div class="nav-label">Sistem</div>
    <div class="nav-item" data-page="settings">
      <span class="nav-icon">⚙️</span> Tənzimləmələr
    </div>
  </nav>
  <div class="sidebar-footer">
    <div class="user-card">
      <div class="user-avatar"><?= strtoupper(substr($userName, 0, 1)) ?></div>
      <div>
        <div class="user-name"><?= htmlspecialchars($userName) ?></div>
        <div class="user-role"><?= $userRole === 'admin' ? 'Administrator' : 'Operator' ?></div>
      </div>
    </div>
    <a href="logout.php" class="nav-item" style="margin-top:8px;color:rgba(255,255,255,.5)">
      <span class="nav-icon">🚪</span> Çıxış
    </a>
  </div>
</aside>

<!-- MAIN -->
<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <button class="hamburger" id="hamburger">☰</button>
      <div class="topbar-title" id="topbarTitle">İdarə Paneli</div>
    </div>
    <div class="topbar-right">
      <div class="topbar-date" id="topbarDate"></div>
      <button class="topbar-btn amber" id="btnNewContract2">➕ Yeni Müqavilə</button>
    </div>
  </div>

  <div class="content">

    <!-- ══ DASHBOARD ══ -->
    <div class="page active" data-page="dashboard">
      <div class="page-header">
        <div>
          <div class="page-title">İdarə Paneli</div>
          <div class="page-sub">Xoş gəldiniz, <?= htmlspecialchars($userName) ?>!</div>
        </div>
      </div>
      <div class="stats-grid">
        <div class="stat-card blue">
          <div class="stat-icon">📋</div>
          <div class="stat-value" id="statTotal">—</div>
          <div class="stat-label">Ümumi Müqavilə</div>
        </div>
        <div class="stat-card amber">
          <div class="stat-icon">⏳</div>
          <div class="stat-value" id="statPending">—</div>
          <div class="stat-label">Gözləyir / Göndərilib</div>
          <div class="stat-sub" id="statSent">—</div>
        </div>
        <div class="stat-card green">
          <div class="stat-icon">✅</div>
          <div class="stat-value" id="statSigned">—</div>
          <div class="stat-label">İmzalanmış</div>
          <div class="stat-sub" id="statMonth">— bu ay</div>
        </div>
        <div class="stat-card purple">
          <div class="stat-icon">💰</div>
          <div class="stat-value" id="statSignedAmt" style="font-size:16px">—</div>
          <div class="stat-label">İmzalanmış Məbləğ</div>
          <div class="stat-sub" id="statAmount">Ümumi: —</div>
        </div>
      </div>
      <div class="card">
        <div class="card-head">
          <div class="card-head-title">📋 Son Müqavilələr</div>
          <button class="action-btn" onclick="showPage('contracts')">Hamısını gör →</button>
        </div>
        <div style="overflow-x:auto">
          <table class="data-table">
            <thead><tr><th>№</th><th>Müştəri</th><th>Telefon</th><th>Status</th><th>Məbləğ</th><th>Tarix</th></tr></thead>
            <tbody id="recentTbody"><tr><td colspan="6" class="dt-empty">Yüklənir...</td></tr></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ══ MÜQAVİLƏLƏR ══ -->
    <div class="page" data-page="contracts">
      <div class="page-header">
        <div>
          <div class="page-title">Müqavilələr</div>
          <div class="page-sub">Bütün müqavilələri idarə edin</div>
        </div>
        <button class="btn btn-amber" onclick="showPage('new')">➕ Yeni Müqavilə</button>
      </div>
      <div class="filter-bar">
        <input type="text" id="searchInput" placeholder="🔍 Ad, müqavilə №, telefon...">
        <select id="statusFilter">
          <option value="">Bütün statuslar</option>
          <option value="pending">Gözləyir</option>
          <option value="sent">Göndərilib</option>
          <option value="signed">İmzalanıb</option>
          <option value="cancelled">Ləğv edilib</option>
        </select>
        <span class="filter-count" id="filterCount">—</span>
      </div>
      <div class="card">
        <div style="overflow-x:auto">
          <table class="data-table">
            <thead>
              <tr><th>Müqavilə №</th><th>Müştəri</th><th>Status</th><th style="text-align:right">Məbləğ</th><th>Tarix</th><th>Əməliyyatlar</th></tr>
            </thead>
            <tbody id="contractsTbody"><tr><td colspan="6" class="dt-empty">Yüklənir...</td></tr></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ══ YENİ MÜQAVİLƏ ══ -->
    <div class="page" data-page="new" id="newPage">
      <div class="page-header">
        <div>
          <div class="page-title">Yeni Müqavilə</div>
          <div class="page-sub">4 addımda peşəkar müqavilə yaradın</div>
        </div>
      </div>
      <div class="card">
        <!-- Wizard steps bar -->
        <div class="wizard-steps-bar">
          <div class="wiz-step active" id="wStep1">
            <div class="wiz-num">1</div>
            <div class="wiz-info"><div class="wiz-lbl">Addım 1</div><div class="wiz-name">Şəxsi Məlumat</div></div>
          </div>
          <div class="wiz-step" id="wStep2">
            <div class="wiz-num">2</div>
            <div class="wiz-info"><div class="wiz-lbl">Addım 2</div><div class="wiz-name">Məhsullar</div></div>
          </div>
          <div class="wiz-step" id="wStep3">
            <div class="wiz-num">3</div>
            <div class="wiz-info"><div class="wiz-lbl">Addım 3</div><div class="wiz-name">Ödəniş</div></div>
          </div>
          <div class="wiz-step" id="wStep4">
            <div class="wiz-num">4</div>
            <div class="wiz-info"><div class="wiz-lbl">Addım 4</div><div class="wiz-name">Nəzərdən Keç</div></div>
          </div>
        </div>

        <!-- Step 1 — Şəxsi -->
        <div class="wiz-section active" data-step="1">
          <div class="fsec-title">👤 Müştəri Şəxsi Məlumatları</div>
          <div class="fg fg-3">
            <div class="field"><label class="fl">Ad <span class="req">*</span></label><input class="inp" id="fFname" placeholder="Əli"></div>
            <div class="field"><label class="fl">Soyad <span class="req">*</span></label><input class="inp" id="fLname" placeholder="Əliyev"></div>
            <div class="field"><label class="fl">Ata adı</label><input class="inp" id="fPatronym" placeholder="Rəşid oğlu"></div>
          </div>
          <div class="fg fg-4">
            <div class="field"><label class="fl">Doğum tarixi</label><input class="inp" type="date" id="fDob"></div>
            <div class="field"><label class="fl">Ş/V nömrəsi <span class="req">*</span></label><input class="inp" id="fIdnum" placeholder="AZE12345678"></div>
            <div class="field"><label class="fl">FİN kodu</label><input class="inp" id="fFin" placeholder="1A2B3C4" maxlength="7"></div>
            <div class="field"><label class="fl">Verən orqan</label><input class="inp" id="fIdauth" placeholder="Daxili İşlər..."></div>
          </div>
          <div class="fg fg-3">
            <div class="field"><label class="fl">Verilmə tarixi</label><input class="inp" type="date" id="fIdissue"></div>
            <div class="field"><label class="fl">Etibarlılıq tarixi</label><input class="inp" type="date" id="fIdexpiry"></div>
            <div class="field"><label class="fl">Telefon <span class="req">*</span></label><input class="inp" id="fPhone" placeholder="+994 50 000 00 00"></div>
          </div>
          <div class="fg fg-2">
            <div class="field"><label class="fl">E-poçt ünvanı</label><input class="inp" type="email" id="fEmail" placeholder="ali@example.com"></div>
            <div class="field"><label class="fl">Qeydiyyat ünvanı <span class="req">*</span></label><input class="inp" id="fAddress" placeholder="Bakı şəh., Nərimanov r., ..."></div>
          </div>
          <div class="fg fg-1">
            <div class="field"><label class="fl">Çatdırılma ünvanı (fərqli isə)</label><input class="inp" id="fDelivery" placeholder="Boş buraxsanız, yuxarıdakı ünvan istifadə olunur"></div>
          </div>
        </div>

        <!-- Step 2 — Məhsullar -->
        <div class="wiz-section" data-step="2">
          <div class="fsec-title">📦 Məhsullar / Xidmətlər</div>
          <div class="vat-box on" id="vatBox" style="margin-bottom:18px">
            <div class="vat-toggle"></div>
            <div class="vat-text">
              <strong>ƏDV Daxildir (18%)</strong>
              <span>Qiymətlərə ƏDV daxildir</span>
            </div>
          </div>
          <div class="items-wrap">
            <table class="items-table">
              <thead>
                <tr><th style="width:36px">#</th><th>Məhsul / Xidmət adı</th><th style="width:70px">Vahid</th><th style="width:80px">Miqdar</th><th style="width:120px">Qiymət (AZN)</th><th style="width:100px;text-align:right">Cəm</th><th style="width:40px"></th></tr>
              </thead>
              <tbody id="itemsTbody"></tbody>
            </table>
          </div>
          <button class="add-row-btn" id="addItemBtn">+ Məhsul / Xidmət Əlavə Et</button>
          <div class="totals-box" style="margin-top:18px">
            <div class="tot-row"><span>Ara cəm</span><span id="dispSubtotal">0.00 AZN</span></div>
            <div class="tot-row"><span>ƏDV</span><span id="dispVat">0.00 AZN</span></div>
            <div class="tot-row final"><span>YEKUN</span><span id="dispTotal">0.00 AZN</span></div>
          </div>
          <input type="hidden" id="fSubtotal">
          <input type="hidden" id="fVat">
          <input type="hidden" id="fTotal">
        </div>

        <!-- Step 3 — Ödəniş -->
        <div class="wiz-section" data-step="3">
          <div class="fsec-title">💳 Ödəniş Şərtləri</div>
          <div class="fg fg-3">
            <div class="field">
              <label class="fl">Ödəniş üsulu</label>
              <select class="inp" id="fPayMethod">
                <option>Nağd</option><option>Bank köçürməsi</option>
                <option>Kredit kartı</option><option>Hissəli ödəniş</option>
              </select>
            </div>
            <div class="field">
              <label class="fl">Valyuta</label>
              <select class="inp" id="fCurrency"><option>AZN</option><option>USD</option><option>EUR</option></select>
            </div>
            <div class="field">
              <label class="fl">Zəmanət müddəti</label>
              <select class="inp" id="fWarranty">
                <option>6 ay</option><option selected>12 ay</option>
                <option>18 ay</option><option>24 ay</option><option>36 ay</option>
              </select>
            </div>
          </div>
          <div class="fg fg-2">
            <div class="field"><label class="fl">İlkin ödəniş (AZN)</label><input class="inp" type="number" min="0" step="0.01" id="fDeposit" value="0"></div>
            <div class="field"><label class="fl">Qalan məbləğ (avtomatik)</label><input class="inp" type="text" id="fRemaining" readonly></div>
          </div>
          <div class="fg fg-3">
            <div class="field"><label class="fl">İlkin ödəniş tarixi</label><input class="inp" type="date" id="fDepositDate"></div>
            <div class="field"><label class="fl">Yekun ödəniş tarixi</label><input class="inp" type="date" id="fFinalDate"></div>
            <div class="field"><label class="fl">Quraşdırma tarixi</label><input class="inp" type="date" id="fInstallDate"></div>
          </div>
          <div class="fg fg-1">
            <div class="field"><label class="fl">Əlavə qeydlər (müqaviləyə əlavə edilir)</label><textarea class="inp" id="fNotes" placeholder="Bu müqavilə ilə bağlı əlavə qeydlər..."></textarea></div>
          </div>
        </div>

        <!-- Step 4 — Nəzərdən keç -->
        <div class="wiz-section" data-step="4">
          <div class="fsec-title">✅ Nəzərdən Keçir &amp; Müqaviləni Yarat</div>
          <p style="font-size:13.5px;color:var(--text-soft);margin-bottom:22px;line-height:1.7">
            Aşağıdakı məlumatları yoxlayın. Müqavilə yaradıldıqdan sonra müştəriyə imza linki göndərə bilərsiniz.<br>
            <strong>Müqavilə şərtləri</strong> Tənzimləmələr bölməsindən idarə olunur və bütün müqavilələrə əlavə edilir.
          </p>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
            <div class="card">
              <div class="card-head"><div class="card-head-title">👤 Müştəri</div></div>
              <div class="detail-grid">
                <div class="detail-item" style="grid-column:span 2"><label>Ad Soyad</label><div class="val" id="rvName">—</div></div>
                <div class="detail-item"><label>Şəxsiyyət</label><div class="val" id="rvId">—</div></div>
                <div class="detail-item"><label>Telefon</label><div class="val" id="rvPhone">—</div></div>
              </div>
            </div>
            <div class="card">
              <div class="card-head"><div class="card-head-title">💰 Maliyyə</div></div>
              <div class="card-body">
                <div class="tot-row"><span>Ara cəm</span><span id="dispSubtotal2">0.00</span></div>
                <div class="tot-row"><span>ƏDV</span><span id="dispVat2">0.00</span></div>
                <div class="tot-row final"><span>YEKUN</span><span id="dispTotal2">0.00</span></div>
                <div class="tot-row" style="margin-top:8px"><span>İlkin ödəniş</span><span id="dispDeposit">0.00</span></div>
                <div class="tot-row"><span>Qalan</span><span id="dispRemaining">0.00</span></div>
              </div>
            </div>
          </div>
        </div>

        <div class="wiz-foot">
          <button class="btn btn-ghost" id="wizPrev" style="display:none">← Geri</button>
          <button class="btn btn-amber" id="wizNext">İrəli →</button>
        </div>
      </div>
    </div>

    <!-- ══ TƏNZİMLƏMƏLƏR ══ -->
    <div class="page" data-page="settings">
      <div class="page-header">
        <div>
          <div class="page-title">Tənzimləmələr</div>
          <div class="page-sub">Şirkət məlumatları, müqavilə şərtləri, hesab ayarları</div>
        </div>
      </div>

      <!-- Şirkət məlumatları -->
      <div class="card" style="margin-bottom:20px">
        <div class="card-head"><div class="card-head-title">🏢 Şirkət Məlumatları</div></div>
        <div class="card-body">
          <form id="settingsForm">
            <div class="fg fg-2">
              <div class="field"><label class="fl">Şirkət adı</label><input class="inp" id="set_company_name"></div>
              <div class="field"><label class="fl">VÖEN</label><input class="inp" id="set_voen"></div>
              <div class="field"><label class="fl">Direktor</label><input class="inp" id="set_director"></div>
              <div class="field"><label class="fl">Telefon</label><input class="inp" id="set_phone"></div>
              <div class="field"><label class="fl">E-poçt</label><input class="inp" id="set_email" type="email"></div>
              <div class="field"><label class="fl">ƏDV faizi (%)</label><input class="inp" id="set_vat_rate" type="number" step="0.1" min="0" max="100"></div>
            </div>
            <div class="fg fg-1">
              <div class="field"><label class="fl">Şirkət ünvanı</label><input class="inp" id="set_address"></div>
            </div>
            <button type="submit" class="btn btn-amber">💾 Şirkət Məlumatlarını Saxla</button>
          </form>
        </div>
      </div>

      <!-- Müqavilə şərtləri -->
      <div class="card" style="margin-bottom:20px">
        <div class="card-head">
          <div class="card-head-title">📜 Müqavilə Şərtləri</div>
          <div style="display:flex;gap:8px">
            <button class="action-btn" onclick="toggleTermsPreview()">Önizləmə</button>
          </div>
        </div>
        <div class="card-body">
          <p style="font-size:13px;color:var(--text-soft);margin-bottom:14px;line-height:1.65">
            Aşağıdakı şərtlər hər müqavilənin <strong>§4. Müqavilə Şərtləri</strong> bölməsində göstəriləcək
            və PDF-ə daxil ediləcək. Redaktə etdikdən sonra saxlayın.
          </p>
          <form id="termsForm">
            <div class="field">
              <label class="fl">Müqavilə Şərtləri Mətni</label>
              <textarea class="terms-editor" id="set_contract_terms" placeholder="Müqavilə şərtlərini buraya daxil edin..."></textarea>
              <div class="terms-hint">
                💡 Hər bölməni yeni sətirdən başlayın. Nömrələmə (1. 2. 1.1.) istifadə edə bilərsiniz.
                Bu mətn bütün yeni müqavilələrə avtomatik əlavə ediləcək.
              </div>
            </div>
            <div class="terms-preview-box" id="termsPreview"></div>
            <div style="margin-top:14px;display:flex;gap:10px;align-items:center">
              <button type="submit" class="btn btn-amber">💾 Müqavilə Şərtlərini Saxla</button>
              <button type="button" class="btn btn-ghost" onclick="resetTerms()">↩ Defolt Şərtlərə Qayıt</button>
            </div>
          </form>
        </div>
      </div>

      <!-- Şifrə -->
      <div class="card" style="margin-bottom:20px">
        <div class="card-head"><div class="card-head-title">🔒 Şifrə Dəyiş</div></div>
        <div class="card-body">
          <form id="passForm" style="max-width:400px">
            <div class="fg fg-1">
              <div class="field"><label class="fl">Köhnə Şifrə</label><input class="inp" type="password" id="oldPass"></div>
              <div class="field"><label class="fl">Yeni Şifrə (min. 6 simvol)</label><input class="inp" type="password" id="newPass"></div>
              <div class="field"><label class="fl">Yeni Şifrə (Təkrar)</label><input class="inp" type="password" id="confirmPass"></div>
            </div>
            <button type="submit" class="btn btn-navy">🔒 Şifrəni Dəyiş</button>
          </form>
        </div>
      </div>

      <!-- Sistem -->
      <div class="card">
        <div class="card-head"><div class="card-head-title">ℹ️ Sistem Məlumatı</div></div>
        <div class="card-body" style="font-size:13.5px;color:var(--text-soft)">
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px">
            <div><div style="color:var(--text-light);font-size:11px;margin-bottom:3px">VERSİYA</div><strong><?= APP_NAME ?> v<?= APP_VERSION ?></strong></div>
            <div><div style="color:var(--text-light);font-size:11px;margin-bottom:3px">PHP</div><strong><?= PHP_VERSION ?></strong></div>
            <div><div style="color:var(--text-light);font-size:11px;margin-bottom:3px">SERVER VAXTİ</div><strong><?= date('d.m.Y H:i') ?></strong></div>
          </div>
        </div>
      </div>
    </div>

  </div><!-- /content -->
</div><!-- /main -->

<!-- DETAIL MODAL -->
<div class="modal-overlay" id="detailModal">
  <div class="modal">
    <div class="modal-head">
      <div class="modal-title">Müqavilə Təfərrüatı</div>
      <button class="modal-close">✕</button>
    </div>
    <div class="modal-body" id="detailBody"></div>
  </div>
</div>

<div class="toast" id="toast"></div>

<script src="assets/js/admin.js"></script>
<script>
// ── Tənzimləmə formları ──────────────────────
const DEFAULT_TERMS = `1. ÜMUMI MÜDDƏALAR\n1.1. Bu müqavilə Azərbaycan Respublikasının müvafiq qanunvericiliyi əsasında bağlanır.\n1.2. Müqavilə hər iki tərəf tərəfindən imzalandıqdan sonra hüquqi qüvvəyə minir.\n\n2. TƏSLİMAT VƏ QƏBUL\n2.1. Mallar/xidmətlər razılaşdırılmış müddət ərzində təhvil verilir.\n2.2. Alıcı malları qəbul etdikdən sonra 3 iş günü ərzində iddia irəli sürə bilər.\n\n3. ÖDƏNİŞ ŞƏRTLƏRI\n3.1. Ödəniş müqavilədə göstərilən valyuta və müddətdə həyata keçirilir.\n3.2. Gecikmə halında hər gün üçün ümumi məbləğin 0.1%-i dəyərində cərimə tətbiq edilir.\n\n4. ZƏMANƏTLİ XİDMƏT\n4.1. Məhsula/xidmətə müqavilədə göstərilən müddət ərzində pulsuz texniki xidmət göstərilir.\n4.2. Zəmanət istifadəçi xətaları nəticəsindən meydana çıxan nasazlıqları əhatə etmir.\n\n5. MƏXFİLİK\n5.1. Tərəflər bir-birinin kommersiya sirrlərini üçüncü şəxslərə açıqlamamağı öhdəsinə götürür.\n\n6. MÜQAVİLƏNİN POZULMASI\n6.1. Hər hansı bir tərəf müqavilə şərtlərini pozarsa, digər tərəf 10 iş günü ərzində xəbərdar etməlidir.\n6.2. Mübahisələr danışıqlar yolu ilə, mümkün olmadıqda isə Azərbaycan məhkəmələri vasitəsilə həll edilir.\n\n7. QÜVVƏYƏ MİNMƏ\n7.1. Müqavilə hər iki tərəfin elektron və ya əl ilə imzası ilə qüvvəyə minir.\n7.2. Müqavilənin şərtlərini dəyişdirmək üçün hər iki tərəfin yazılı razılığı tələb olunur.`;

function toggleTermsPreview() {
  const ta  = document.getElementById('set_contract_terms');
  const box = document.getElementById('termsPreview');
  if (box.style.display === 'block') {
    box.style.display = 'none';
  } else {
    box.style.display = 'block';
    box.textContent   = ta?.value || '(Boş)';
  }
}

function resetTerms() {
  if (!confirm('Müqavilə şərtlərini defolt mətnə sıfırlamaq istəyirsiniz?')) return;
  const ta = document.getElementById('set_contract_terms');
  if (ta) ta.value = DEFAULT_TERMS;
  showToast('Defolt şərtlər yükləndi', 'ok');
}

document.getElementById('termsForm')?.addEventListener('submit', async e => {
  e.preventDefault();
  const contract_terms = document.getElementById('set_contract_terms')?.value || '';
  try {
    await apiFetch(`${API}?action=settings`, { method: 'POST', body: JSON.stringify({ contract_terms }) });
    showToast('Müqavilə şərtləri saxlanıldı', 'ok');
    // Önizlənəni yenilə
    const box = document.getElementById('termsPreview');
    if (box.style.display === 'block') box.textContent = contract_terms;
  } catch (e) { showToast(e.message, 'err'); }
});

// Sidebar-da VÖEN-i göstər
async function updateSidebarVoen() {
  try {
    const s = await apiFetch(`${API}?action=settings`);
    const el = document.getElementById('sidebarVoen');
    if (el && s.voen) el.textContent = 'VÖEN: ' + s.voen;
  } catch(e) {}
}
updateSidebarVoen();

// Review wizard sync
document.addEventListener('click', e => {
  const btn = document.getElementById('wizNext');
  if (e.target !== btn) return;
  if (typeof wizStep === 'undefined') return;
  if (wizStep === 3) {
    setTimeout(() => {
      const get = id => (document.getElementById(id)?.value || '').trim();
      const fname = get('fFname'), lname = get('fLname');
      const el = id => document.getElementById(id);
      if (el('rvName'))  el('rvName').textContent  = [fname, lname].filter(Boolean).join(' ') || '—';
      if (el('rvId'))    el('rvId').textContent    = get('fIdnum') || '—';
      if (el('rvPhone')) el('rvPhone').textContent = get('fPhone') || '—';
      if (el('dispSubtotal2')) el('dispSubtotal2').textContent = el('dispSubtotal')?.textContent || '0.00';
      if (el('dispVat2'))      el('dispVat2').textContent      = el('dispVat')?.textContent      || '0.00';
      if (el('dispTotal2'))    el('dispTotal2').textContent    = el('dispTotal')?.textContent    || '0.00';
    }, 50);
  }
}, true);
</script>

</body>
</html>
