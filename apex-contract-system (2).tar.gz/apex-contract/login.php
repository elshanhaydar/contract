<?php
// ══════════════════════════════════════════════
//  APEX — Giriş Səhifəsi v3
//  login.php
// ══════════════════════════════════════════════
require_once 'config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

if (is_logged_in()) { header('Location: index.php'); exit; }

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($username && $password) {
        try {
            $st = db()->prepare("SELECT * FROM users WHERE username = ? LIMIT 1");
            $st->execute([$username]);
            $user = $st->fetch();
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['apex_admin'] = true;
                $_SESSION['apex_user']  = $user['username'];
                $_SESSION['apex_name']  = $user['name'] ?? $user['username'];
                $_SESSION['apex_role']  = $user['role'];
                $_SESSION['apex_time']  = time();
                session_regenerate_id(true);
                header('Location: index.php'); exit;
            } else {
                $error = 'İstifadəçi adı və ya şifrə yanlışdır.';
            }
        } catch (PDOException $e) {
            if (login_attempt($username, $password)) {
                do_login(); header('Location: index.php'); exit;
            }
            $error = 'Sistem xətası. install.php icra edilib?';
        }
    } else {
        $error = 'Bütün sahələri doldurun.';
    }
}
?>
<!DOCTYPE html>
<html lang="az">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Apex Industries — Giriş</title>
<link rel="stylesheet" href="assets/css/login.css">
</head>
<body>

<div class="login-bg">

  <!-- ── Sol panel ── -->
  <div class="login-left">
    <div class="login-left-grid"></div>
    <div class="ll-inner">
      <div class="ll-logo">
        <div class="ll-emblem">A</div>
        <div>
          <div class="ll-brand">Apex Industries</div>
          <div class="ll-sub">MMC</div>
        </div>
      </div>

      <div class="ll-tagline">Peşəkar<br><span>Müqavilə</span> İdarəetmə</div>
      <div class="ll-desc">
        Rəqəmsal müqavilə dövriyyəsini asanlaşdırın. Yaradın, göndərin, imzalayın — hamısı bir yerdə.
      </div>

      <div class="ll-features">
        <div class="ll-feature"><div class="lf-dot"></div> Sürətli rəqəmsal müqavilə yaratma</div>
        <div class="ll-feature"><div class="lf-dot"></div> Müştəri elektron imzası (mobil + masaüstü)</div>
        <div class="ll-feature"><div class="lf-dot"></div> Peşəkar PDF ixrac &amp; arxivləmə</div>
        <div class="ll-feature"><div class="lf-dot"></div> Müqavilə şərtlərini asanlıqla idarə edin</div>
      </div>
    </div>
  </div>

  <!-- ── Sağ panel ── -->
  <div class="login-right">
    <div class="login-card">
      <div class="lc-head">
        <div class="lc-title">Xoş gəldiniz</div>
        <div class="lc-sub">Admin panelinə daxil olmaq üçün<br>hesab məlumatlarınızı daxil edin</div>
      </div>

      <?php if ($error): ?>
        <div class="lc-error">
          <span class="le-icon">⚠</span>
          <?= htmlspecialchars($error) ?>
        </div>
      <?php endif; ?>

      <form method="POST" action="login.php" class="lc-form" autocomplete="off">
        <div class="lf-group">
          <label class="lf-label" for="username">İstifadəçi Adı</label>
          <div class="lf-input-wrap">
            <span class="lf-icon-left">👤</span>
            <input type="text" id="username" name="username" class="lf-input"
              placeholder="admin"
              value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
              required autofocus>
          </div>
        </div>

        <div class="lf-group">
          <label class="lf-label" for="password">Şifrə</label>
          <div class="lf-input-wrap">
            <span class="lf-icon-left">🔒</span>
            <input type="password" id="password" name="password" class="lf-input"
              placeholder="••••••••" required>
            <button type="button" class="lf-eye" onclick="togglePass()" title="Şifrəni göstər">👁</button>
          </div>
        </div>

        <button type="submit" class="lf-btn">
          <span>Daxil Ol</span>
          <span class="lf-btn-arrow">→</span>
        </button>
      </form>

      <div class="lc-footer">
        🔐 Təhlükəsiz şifrələmə ilə qorunur
      </div>
    </div>
  </div>

</div>

<script>
function togglePass() {
  const inp = document.getElementById('password');
  inp.type = inp.type === 'password' ? 'text' : 'password';
}
</script>
</body>
</html>
