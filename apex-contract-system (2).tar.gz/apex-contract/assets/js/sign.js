// ══════════════════════════════════════════════
//  APEX — Sign Page JS (v2)
//  assets/js/sign.js
// ══════════════════════════════════════════════

const API   = 'api.php';
const token = new URLSearchParams(location.search).get('t') || '';

let contractData = null;

// ── UTILITIES ─────────────────────────────────
function fmt(n)     { return Number(n).toLocaleString('az-AZ', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
function fmtDate(d) { if (!d) return '—'; return d.substring(0, 10).split('-').reverse().join('.'); }
function esc(s)     { const e = document.createElement('span'); e.textContent = s || ''; return e.innerHTML; }
function setText(id, val) { const el = document.getElementById(id); if (el) el.textContent = val ?? '—'; }
function setHtml(id, val) { const el = document.getElementById(id); if (el) el.innerHTML = val;  }

let _toastTimer;
function showToast(msg, type = '') {
  let t = document.getElementById('toast');
  t.className = 'toast ' + type;
  t.textContent = msg;
  clearTimeout(_toastTimer);
  setTimeout(() => t.classList.add('show'), 10);
  _toastTimer = setTimeout(() => t.classList.remove('show'), 3800);
}

function showScreen(id) {
  document.querySelectorAll('.state-screen').forEach(s => s.classList.remove('active'));
  const el = document.getElementById(id);
  if (el) el.classList.add('active');
}

function setProgress(pct) {
  const el = document.getElementById('progressFill');
  if (el) el.style.width = pct + '%';
}

// ── LOAD CONTRACT ─────────────────────────────
async function loadContract() {
  if (!token) { showScreen('screenError'); setText('errBody', 'Keçərsiz link.'); return; }

  try {
    const r    = await fetch(`${API}?action=sign_get&token=${encodeURIComponent(token)}`);
    const data = await r.json();

    if (!r.ok) {
      if (r.status === 410) { showScreen('screenCancelled'); return; }
      showScreen('screenError');
      setText('errBody', data.error || 'Müqavilə tapılmadı.');
      return;
    }

    contractData = data;

    if (data.status === 'signed') { showAlreadySigned(data); return; }

    renderContract(data);
    document.getElementById('screenContract').style.display = 'block';
    showScreen('screenContract');
    setProgress(25);

  } catch (e) {
    showScreen('screenError');
    setText('errBody', 'Serverlə əlaqə qurulamadı.');
  }
}

// ── RENDER CONTRACT ───────────────────────────
function renderContract(c) {
  const company = c._company || {};

  // Header
  setText('cCompany', company.name || 'Apex Industries MMC');
  setText('cVoen',    company.voen ? 'VÖEN: ' + company.voen : '');
  setText('cNo',      c.contract_no);
  setText('cDate',    'Tarix: ' + fmtDate(c.created_at));
  setText('cStatus',  { pending: 'Gözləyir', sent: 'Göndərilib', signed: 'İmzalandı' }[c.status] || c.status);

  // §1 Tərəflər — simmetrik
  buildPartyBox('partyCompany', 'SATICI', [
    ['Şirkət',    company.name],
    ['VÖEN',      company.voen],
    ['Direktor',  company.director],
    ['Telefon',   company.phone],
    ['Ünvan',     company.address],
  ]);

  buildPartyBox('partyClient', 'ALICI (MÜŞTƏRİ)', [
    ['Ad, Soyad',    [c.fname, c.lname, c.patronym].filter(Boolean).join(' ')],
    ['Ş/V Seriya №', c.idnum || '—'],
    ['FİN kodu',     c.fin   || '—'],
  ]);

  // §2 Mallar
  buildItemsTable(c);

  // §3 Ödəniş
  const vatLabel = c.vat_included
    ? '<span class="vat-badge">ƏDV 18% daxil</span>'
    : '<span class="vat-badge no-vat-badge">ƏDV yoxdur</span>';

  setHtml('totalsBox', `
    <div class="totals">
      <div class="tot-row"><span>Ara cəm ${vatLabel}</span><span>${fmt(c.subtotal)} ${c.currency || 'AZN'}</span></div>
      <div class="tot-row"><span>ƏDV (${c.vat_included ? '18%' : '0%'})</span><span>${fmt(c.vat)} ${c.currency || 'AZN'}</span></div>
      <div class="tot-row final"><span>YEKUN MƏBLƏğ</span><span>${fmt(c.total)} ${c.currency || 'AZN'}</span></div>
    </div>`);

  setHtml('paymentBox', `
    <div class="pay-grid">
      <div class="pay-item"><label>Ödəniş Üsulu</label><div class="val">${esc(c.pay_method || 'Nağd')}</div></div>
      <div class="pay-item"><label>Valyuta</label><div class="val">${esc(c.currency || 'AZN')}</div></div>
      <div class="pay-item"><label>İlkin Ödəniş</label><div class="val">${fmt(c.deposit)} ${esc(c.currency || 'AZN')}</div></div>
      <div class="pay-item"><label>Qalan Məbləğ</label><div class="val">${fmt(c.remaining)} ${esc(c.currency || 'AZN')}</div></div>
      <div class="pay-item"><label>Ödəniş Tarixi</label><div class="val">${fmtDate(c.deposit_date)}</div></div>
      <div class="pay-item"><label>Yekun Tarix</label><div class="val">${fmtDate(c.final_date)}</div></div>
      <div class="pay-item"><label>Quraşdırma</label><div class="val">${fmtDate(c.install_date)}</div></div>
      <div class="pay-item"><label>Zəmanət</label><div class="val">${esc(c.warranty || '12 ay')}</div></div>
    </div>`);

  // §4 Müqavilə şərtləri
  const terms = c._company?.terms || '';
  const termsSection = document.getElementById('termsSection');
  if (termsSection) {
    if (terms) {
      termsSection.style.display = '';
      const el = document.getElementById('termsText');
      if (el) el.innerHTML = terms.replace(/\n/g, '<br>');
    } else {
      termsSection.style.display = 'none';
    }
  }

  // §5 Qeydlər
  const notesSection = document.getElementById('notesSection');
  if (notesSection) {
    if (c.notes) {
      notesSection.style.display = '';
      setText('notesText', c.notes);
    } else {
      notesSection.style.display = 'none';
    }
  }
}

function buildPartyBox(id, heading, rows) {
  const el = document.getElementById(id);
  if (!el) return;
  el.innerHTML = `
    <div class="party-head"><div class="party-head-title">${esc(heading)}</div></div>
    <div class="party-body">
      ${rows.map(([l, v]) => `
        <div class="party-row">
          <label>${esc(l)}</label>
          <span class="val">${esc(v || '—')}</span>
        </div>`).join('')}
    </div>`;
}

function buildItemsTable(c) {
  const wrap  = document.getElementById('itemsSection');
  if (!wrap) return;
  const items = c.items || [];
  if (!items.length) { wrap.innerHTML = '<p style="color:var(--text-light);font-size:13px;padding:8px 0">Mal/xidmət əlavə edilməyib.</p>'; return; }

  wrap.innerHTML = `<div style="overflow-x:auto">
    <table class="prod-table">
      <thead><tr>
        <th style="width:36px">#</th>
        <th>Məhsul / Xidmət</th>
        <th>Vahid</th>
        <th style="text-align:center">Miqdar</th>
        <th class="num">Qiymət</th>
        <th class="num">Cəm</th>
      </tr></thead>
      <tbody>
        ${items.map((it, i) => `
          <tr style="background:${i%2===0?'#fff':'#f8fafd'}">
            <td style="color:var(--text-light);font-size:12px;text-align:center">${i + 1}</td>
            <td><strong>${esc(it.name || '')}</strong></td>
            <td>${esc(it.unit || 'əd')}</td>
            <td style="text-align:center">${esc(String(it.qty || 1))}</td>
            <td class="num">${fmt(it.price || 0)}</td>
            <td class="num"><strong>${fmt((it.qty || 1) * (it.price || 0))}</strong></td>
          </tr>`).join('')}
      </tbody>
    </table>
  </div>`;
}

// ── ALREADY SIGNED ────────────────────────────
function showAlreadySigned(c) {
  const b = document.getElementById('alreadySignedBody');
  if (b) b.textContent = `Bu müqavilə ${fmtDate(c.signed_at)} tarixdə imzalanmışdır.`;
  showScreen('screenAlreadySigned');
  setProgress(100);
}

// ══════════════════════════════════════════════
//  CANVAS İMZA  (Mouse + Touch düzgün işləyir)
// ══════════════════════════════════════════════
let canvas, ctx;
let drawing   = false;
let hasSig    = false;
let lastX     = 0;
let lastY     = 0;

function initCanvas() {
  canvas = document.getElementById('signCanvas');
  if (!canvas) return;
  ctx = canvas.getContext('2d');
  resizeCanvas();

  // ── MOUSE EVENTS ──
  canvas.addEventListener('mousedown', onDown);
  canvas.addEventListener('mousemove', onMove);
  canvas.addEventListener('mouseup',   onUp);
  canvas.addEventListener('mouseleave',onUp);

  // ── TOUCH EVENTS ──
  canvas.addEventListener('touchstart', e => { e.preventDefault(); onDown(e.touches[0]); }, { passive: false });
  canvas.addEventListener('touchmove',  e => { e.preventDefault(); onMove(e.touches[0]); }, { passive: false });
  canvas.addEventListener('touchend',   e => { e.preventDefault(); onUp();               }, { passive: false });

  window.addEventListener('resize', resizeCanvas);
}

function resizeCanvas() {
  // Save existing drawing
  const imgData = (canvas.width > 0 && canvas.height > 0 && hasSig)
    ? ctx.getImageData(0, 0, canvas.width, canvas.height) : null;

  const dpr  = window.devicePixelRatio || 1;
  const rect  = canvas.parentElement.getBoundingClientRect();
  const w     = rect.width;
  const h     = 200;

  canvas.width  = w * dpr;
  canvas.height = h * dpr;
  canvas.style.width  = w + 'px';
  canvas.style.height = h + 'px';

  ctx.scale(dpr, dpr);
  ctx.strokeStyle = '#0b1628';
  ctx.lineWidth   = 2.4;
  ctx.lineCap     = 'round';
  ctx.lineJoin    = 'round';

  if (imgData) ctx.putImageData(imgData, 0, 0);
}

function getCanvasPos(e) {
  const rect = canvas.getBoundingClientRect();
  const dpr  = window.devicePixelRatio || 1;
  // clientX/Y from both MouseEvent and Touch
  const clientX = e.clientX ?? (e.touches && e.touches[0]?.clientX) ?? 0;
  const clientY = e.clientY ?? (e.touches && e.touches[0]?.clientY) ?? 0;
  return {
    x: (clientX - rect.left),
    y: (clientY - rect.top),
  };
}

function onDown(e) {
  drawing = true;
  const pos = getCanvasPos(e);
  lastX = pos.x;
  lastY = pos.y;
  ctx.beginPath();
  ctx.moveTo(pos.x, pos.y);
  canvas.parentElement.classList.add('drawing');
}

function onMove(e) {
  if (!drawing) return;
  const pos = getCanvasPos(e);
  ctx.beginPath();
  ctx.moveTo(lastX, lastY);
  ctx.lineTo(pos.x, pos.y);
  ctx.stroke();
  lastX = pos.x;
  lastY = pos.y;
  hasSig = true;
  updateSignBtn();
  setProgress(60);
}

function onUp() {
  if (!drawing) return;
  drawing = false;
  canvas.parentElement.classList.remove('drawing');
}

function updateSignBtn() {
  const agreed = document.getElementById('agreeCheck')?.checked;
  const btn    = document.getElementById('btnSign');
  if (btn) btn.disabled = !(agreed && hasSig);
}

function clearSignature() {
  if (!canvas) return;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  hasSig = false;
  updateSignBtn();
  setProgress(25);
}

// ── AGREE CHECKBOX ─────────────────────────────
document.getElementById('agreeCheck')?.addEventListener('change', updateSignBtn);

// ══════════════════════════════════════════════
//  İMZALA
// ══════════════════════════════════════════════
document.getElementById('btnSign')?.addEventListener('click', async function () {
  if (!hasSig) { showToast('Zəhmət olmasa imza atın', 'err'); return; }
  if (!document.getElementById('agreeCheck')?.checked) { showToast('Razılığı təsdiqləyin', 'err'); return; }

  const sigData = canvas.toDataURL('image/png');

  this.disabled = true;
  this.innerHTML = '<div class="spinner" style="display:inline-block;border-top-color:var(--navy)"></div> İmzalanır...';
  setProgress(85);

  try {
    const r = await fetch(`${API}?action=sign_submit&token=${encodeURIComponent(token)}`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ signature: sigData }),
    });
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || 'Xəta baş verdi');

    setProgress(100);
    showSuccessScreen(data, sigData);
  } catch (e) {
    showToast(e.message, 'err');
    this.disabled = false;
    this.innerHTML = '✍️ Müqaviləni İmzala';
  }
});

function showSuccessScreen(c, sigData) {
  document.getElementById('screenContract').style.display = 'none';
  const success = document.getElementById('screenSuccess');
  if (success) { success.style.display = ''; success.classList.add('active'); }

  setText('successNo',   c.contract_no);
  setText('successDate', fmtDate(c.signed_at));

  const preview = document.getElementById('sigPreview');
  if (preview) preview.src = sigData;

  const pdfBtn = document.getElementById('pdfDownloadBtn');
  if (pdfBtn) pdfBtn.href = `pdf.php?t=${encodeURIComponent(token)}`;
}

// ══════════════════════════════════════════════
//  MÜQAVİLƏ ŞƏRTLƏRİ MODALI
// ══════════════════════════════════════════════
let termsAccepted = false;
let termsReadPct   = 0;

function openTermsModal() {
  const modal   = document.getElementById('termsModal');
  const content = document.getElementById('tmContent');
  if (!modal || !content) return;

  // Şərtləri doldur
  const terms = contractData?._company?.terms || '';
  if (terms) {
    content.innerHTML = terms.replace(/\n/g, '<br>');
  } else {
    content.innerHTML = '<div class="tm-no-terms">ℹ️ Bu müqavilə üçün əlavə şərt müəyyən edilməyib.<br><br>Standart satış şərtləri tətbiq olunur.</div>';
  }

  modal.classList.add('open');
  document.body.style.overflow = 'hidden';

  // Scroll sıfırla
  const body = document.getElementById('tmBody');
  if (body) {
    body.scrollTop = 0;
    // Əgər şərt yoxdursa — dərhal qəbul düyməsini aktiv et
    if (!terms) {
      setTermsReadPct(100);
    } else {
      setTermsReadPct(termsAccepted ? 100 : 0);
      body.addEventListener('scroll', onTermsScroll);
    }
  }
}

function closeTermsModal() {
  const modal = document.getElementById('termsModal');
  if (modal) modal.classList.remove('open');
  document.body.style.overflow = '';
  const body = document.getElementById('tmBody');
  if (body) body.removeEventListener('scroll', onTermsScroll);
}

function handleModalOverlayClick(e) {
  if (e.target === document.getElementById('termsModal')) closeTermsModal();
}

function onTermsScroll() {
  const body = document.getElementById('tmBody');
  if (!body) return;
  const { scrollTop, scrollHeight, clientHeight } = body;
  const scrollable = scrollHeight - clientHeight;
  if (scrollable <= 0) { setTermsReadPct(100); return; }
  const pct = Math.round((scrollTop / scrollable) * 100);
  setTermsReadPct(pct);
}

function setTermsReadPct(pct) {
  termsReadPct = pct;
  const fill   = document.getElementById('tmProgressFill');
  const label  = document.getElementById('tmProgressLabel');
  const hint   = document.getElementById('tmReadHint');
  const done   = document.getElementById('tmReadDone');
  const btn    = document.getElementById('tmAcceptBtn');
  if (fill)  fill.style.width = pct + '%';
  if (label) label.textContent = pct + '% oxundu';
  const fullyRead = pct >= 90;
  if (hint) hint.style.display = fullyRead ? 'none' : '';
  if (done) done.style.display = fullyRead ? ''     : 'none';
  if (btn)  btn.disabled = !fullyRead;
}

function acceptTerms() {
  termsAccepted = true;

  // Checkbox-u işarələ
  const cb = document.getElementById('agreeCheck');
  if (cb) { cb.checked = true; cb.dispatchEvent(new Event('change')); }

  // Razılıq bölməsini yenilə
  const status = document.getElementById('termsStatus');
  const label  = document.getElementById('agreeCheckLabel');
  if (status) status.style.display = 'flex';
  if (label)  label.style.display  = 'none';

  closeTermsModal();
  showToast('Şərtlər qəbul edildi!', 'ok');
  updateSignBtn();
}

// Escape ilə modalu bağla
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeTermsModal();
});

// ── INIT ──────────────────────────────────────
initCanvas();
loadContract();
