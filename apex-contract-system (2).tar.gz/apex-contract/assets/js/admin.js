// ══════════════════════════════════════════════
//  APEX — Admin Panel JS
//  assets/js/admin.js
// ══════════════════════════════════════════════

const API = 'api.php';

// ── UTILITIES ─────────────────────────────────
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

let toastTimer;
function showToast(msg, type = '') {
  let t = document.getElementById('toast');
  if (!t) { t = document.createElement('div'); t.id = 'toast'; t.className = 'toast'; document.body.appendChild(t); }
  t.className = 'toast ' + type;
  t.textContent = msg;
  clearTimeout(toastTimer);
  setTimeout(() => t.classList.add('show'), 10);
  toastTimer = setTimeout(() => t.classList.remove('show'), 3500);
}

async function apiFetch(url, opts = {}) {
  const r = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...opts });
  const data = await r.json();
  if (!r.ok) throw new Error(data.error || 'Xəta baş verdi');
  return data;
}

function fmt(n) { return Number(n).toLocaleString('az-AZ', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
function fmtDate(d) { if (!d) return '—'; return d.substring(0, 10).split('-').reverse().join('.'); }
function esc(s) { const e = document.createElement('span'); e.textContent = s; return e.innerHTML; }

// ── NAVIGATION ────────────────────────────────
const navItems = $$('.nav-item');
const pages    = $$('.page');

function showPage(name) {
  pages.forEach(p => p.classList.toggle('active', p.dataset.page === name));
  navItems.forEach(n => n.classList.toggle('active', n.dataset.page === name));
  const titles = { dashboard: 'İdarə Paneli', contracts: 'Müqavilələr', new: 'Yeni Müqavilə', settings: 'Tənzimləmələr' };
  const ttEl = document.getElementById('topbarTitle');
  if (ttEl) ttEl.textContent = titles[name] || name;
  if (name === 'dashboard') loadDashboard();
  if (name === 'contracts') loadContracts();
}

navItems.forEach(item => {
  item.addEventListener('click', () => {
    if (item.dataset.page) showPage(item.dataset.page);
  });
});

// ── TOPBAR DATE ───────────────────────────────
(function() {
  const el = document.getElementById('topbarDate');
  if (!el) return;
  const now = new Date();
  el.textContent = now.toLocaleDateString('az-AZ', { day: '2-digit', month: 'long', year: 'numeric' });
})();

// ── HAMBURGER ─────────────────────────────────
const hamburger = document.getElementById('hamburger');
const sidebar   = document.getElementById('sidebar');
if (hamburger && sidebar) {
  hamburger.addEventListener('click', () => sidebar.classList.toggle('open'));
  document.addEventListener('click', e => {
    if (!sidebar.contains(e.target) && !hamburger.contains(e.target)) sidebar.classList.remove('open');
  });
}

// ══════════════════════════════════════════════
//  DASHBOARD
// ══════════════════════════════════════════════
async function loadDashboard() {
  try {
    const s = await apiFetch(`${API}?action=stats`);
    setText('statTotal',     s.total);
    setText('statPending',   s.pending);
    setText('statSent',      s.sent);
    setText('statSigned',    s.signed);
    setText('statCancelled', s.cancelled);
    setText('statAmount',    fmt(s.total_amount) + ' AZN');
    setText('statSignedAmt', fmt(s.signed_amount) + ' AZN');
    setText('statMonth',     s.month_signed);

    // Son müqavilələr
    const contracts = await apiFetch(`${API}?action=contracts`);
    renderRecentTable(contracts.slice(0, 8));
  } catch (e) {
    showToast(e.message, 'err');
  }
}

function setText(id, val) { const el = document.getElementById(id); if (el) el.textContent = val ?? '—'; }

function renderRecentTable(list) {
  const tbody = document.getElementById('recentTbody');
  if (!tbody) return;
  if (!list.length) { tbody.innerHTML = '<tr><td colspan="6" class="dt-empty">Müqavilə yoxdur</td></tr>'; return; }
  tbody.innerHTML = list.map(c => `
    <tr onclick="openDetail(${c.id})">
      <td><strong>${esc(c.contract_no)}</strong></td>
      <td>${esc(c.fname + ' ' + c.lname)}</td>
      <td>${esc(c.phone)}</td>
      <td><span class="badge ${statusClass(c.status)}">${statusLabel(c.status)}</span></td>
      <td><strong>${fmt(c.total)}</strong> ${esc(c.currency)}</td>
      <td>${fmtDate(c.created_at)}</td>
    </tr>`).join('');
}

// ══════════════════════════════════════════════
//  MÜQAVİLƏLƏR SİYAHISI
// ══════════════════════════════════════════════
let allContracts = [];

async function loadContracts() {
  const tbody = document.getElementById('contractsTbody');
  if (!tbody) return;
  try {
    allContracts = await apiFetch(`${API}?action=contracts`);
    renderContracts(allContracts);
    updateFilterCounts();
  } catch (e) {
    showToast(e.message, 'err');
  }
}

function renderContracts(list) {
  const tbody = document.getElementById('contractsTbody');
  if (!tbody) return;
  if (!list.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="dt-empty">Heç bir müqavilə tapılmadı</td></tr>';
    return;
  }
  tbody.innerHTML = list.map(c => `
    <tr onclick="openDetail(${c.id})">
      <td><strong style="font-family:var(--font-head);font-size:14px">${esc(c.contract_no)}</strong></td>
      <td>
        <div style="font-weight:600">${esc(c.fname + ' ' + c.lname)}</div>
        <div style="font-size:11.5px;color:var(--text-light)">${esc(c.phone)}</div>
      </td>
      <td><span class="badge ${statusClass(c.status)}">${statusLabel(c.status)}</span></td>
      <td style="text-align:right;font-weight:600">${fmt(c.total)} ${esc(c.currency)}</td>
      <td>${fmtDate(c.created_at)}</td>
      <td onclick="event.stopPropagation()" style="white-space:nowrap">
        ${actionBtns(c)}
      </td>
    </tr>`).join('');
}

function actionBtns(c) {
  let btns = `<button class="action-btn" onclick="openDetail(${c.id})">Bax</button> `;
  if (c.status === 'pending' || c.status === 'sent') {
    btns += `<button class="action-btn success" onclick="sendContract(${c.id})">Göndər</button> `;
  }
  if (c.status !== 'signed' && c.status !== 'cancelled') {
    btns += `<button class="action-btn danger" onclick="cancelContract(${c.id})">Ləğv et</button> `;
  }
  if (c.status === 'signed') {
    btns += `<a class="action-btn" href="pdf.php?id=${c.id}" target="_blank">PDF</a> `;
  }
  return btns;
}

// Axtarış & Filter
function filterContracts() {
  const q      = ($('#searchInput')?.value || '').toLowerCase();
  const status = $('#statusFilter')?.value || '';
  const filtered = allContracts.filter(c => {
    const matchQ = !q || [c.contract_no, c.fname, c.lname, c.phone, c.idnum].some(f => (f||'').toLowerCase().includes(q));
    const matchS = !status || c.status === status;
    return matchQ && matchS;
  });
  renderContracts(filtered);
  const cnt = document.getElementById('filterCount');
  if (cnt) cnt.textContent = `${filtered.length} nəticə`;
}

function updateFilterCounts() {
  const cnt = document.getElementById('filterCount');
  if (cnt) cnt.textContent = `${allContracts.length} müqavilə`;
}

document.getElementById('searchInput')?.addEventListener('input', filterContracts);
document.getElementById('statusFilter')?.addEventListener('change', filterContracts);

// ══════════════════════════════════════════════
//  SEND / CANCEL
// ══════════════════════════════════════════════
async function sendContract(id) {
  if (!confirm('Bu müqaviləni göndərilmiş kimi işarələmək istəyirsiniz?')) return;
  try {
    await apiFetch(`${API}?action=send&id=${id}`, { method: 'POST' });
    showToast('Müqavilə göndərildi', 'ok');
    loadContracts(); loadDashboard();
  } catch (e) { showToast(e.message, 'err'); }
}

async function cancelContract(id) {
  if (!confirm('Bu müqaviləni ləğv etmək istəyirsiniz?')) return;
  try {
    await apiFetch(`${API}?action=cancel&id=${id}`, { method: 'POST' });
    showToast('Müqavilə ləğv edildi');
    loadContracts(); loadDashboard();
    closeModal('detailModal');
  } catch (e) { showToast(e.message, 'err'); }
}

async function deleteContract(id) {
  if (!confirm('Bu müqaviləni silmək istəyirsiniz? Bu əməliyyat geri alına bilməz!')) return;
  try {
    await apiFetch(`${API}?action=contract&id=${id}`, { method: 'DELETE' });
    showToast('Müqavilə silindi');
    loadContracts(); loadDashboard();
    closeModal('detailModal');
  } catch (e) { showToast(e.message, 'err'); }
}

// ══════════════════════════════════════════════
//  MODAL HELPERLƏRİ
// ══════════════════════════════════════════════
function openModal(id) { document.getElementById(id)?.classList.add('open'); }
function closeModal(id){ document.getElementById(id)?.classList.remove('open'); }

$$('.modal-overlay').forEach(ov => {
  ov.addEventListener('click', e => { if (e.target === ov) closeModal(ov.id); });
});
$$('.modal-close').forEach(btn => {
  btn.addEventListener('click', () => closeModal(btn.closest('.modal-overlay').id));
});

// ══════════════════════════════════════════════
//  DETAIL MODAL
// ══════════════════════════════════════════════
async function openDetail(id) {
  openModal('detailModal');
  const body = document.getElementById('detailBody');
  body.innerHTML = '<div style="text-align:center;padding:40px"><div class="spinner" style="display:inline-block;border-color:var(--amber);border-top-color:var(--navy)"></div></div>';

  try {
    const c = await apiFetch(`${API}?action=contract&id=${id}`);
    renderDetail(c, body);
  } catch (e) {
    body.innerHTML = `<p style="color:var(--danger)">${e.message}</p>`;
  }
}

function renderDetail(c, container) {
  const signUrl = `${location.origin}${location.pathname.replace('index.php','')}sign.php?t=${c.sign_token}`;
  const [slbl, scls] = [statusLabel(c.status), statusClass(c.status)];

  let itemsHtml = '';
  if (c.items && c.items.length) {
    itemsHtml = `<table class="data-table" style="margin-top:8px">
      <thead><tr><th>#</th><th>Məhsul</th><th>Vahid</th><th>Miqdar</th><th style="text-align:right">Qiymət</th><th style="text-align:right">Cəm</th></tr></thead>
      <tbody>${c.items.map((it, i) => `<tr>
        <td>${i+1}</td><td>${esc(it.name||'')}</td><td>${esc(it.unit||'əd')}</td>
        <td>${esc(String(it.qty||1))}</td>
        <td style="text-align:right">${fmt(it.price||0)}</td>
        <td style="text-align:right"><strong>${fmt((it.qty||1)*(it.price||0))}</strong></td>
      </tr>`).join('')}</tbody>
    </table>`;
  }

  const sigImg = c.signature ? `<div style="margin-top:8px"><img src="${c.signature}" style="max-width:200px;border:1px solid var(--border);border-radius:8px;padding:6px"></div>` : '';

  container.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;flex-wrap:wrap;gap:10px">
      <div>
        <span style="font-family:var(--font-head);font-size:22px;font-weight:700">${esc(c.contract_no)}</span>
        <span class="badge ${scls}" style="margin-left:10px">${slbl}</span>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        ${c.status !== 'signed' && c.status !== 'cancelled' ? `<button class="btn btn-amber" onclick="sendContract(${c.id})">Göndər</button>` : ''}
        ${c.status === 'signed' ? `<a class="btn btn-navy" href="pdf.php?id=${c.id}" target="_blank">PDF İxrac</a>` : ''}
        ${c.status !== 'signed' && c.status !== 'cancelled' ? `<button class="btn btn-ghost" onclick="cancelContract(${c.id})">Ləğv et</button>` : ''}
        <button class="btn btn-danger" onclick="deleteContract(${c.id})">Sil</button>
      </div>
    </div>

    <div style="font-size:12px;color:var(--text-light);margin-bottom:16px">
      Yaradıldı: ${fmtDate(c.created_at)}
      ${c.sent_at   ? ' · Göndərildi: ' + fmtDate(c.sent_at) : ''}
      ${c.signed_at ? ' · İmzalandı: '  + fmtDate(c.signed_at) : ''}
    </div>

    ${c.status === 'sent' || c.status === 'pending' ? `
    <div class="sign-link-box" style="margin-bottom:18px">
      <span style="font-size:12px;color:var(--text-soft);flex-shrink:0">İmza linki:</span>
      <span class="slb-url">${esc(signUrl)}</span>
      <button class="slb-copy" onclick="copyLink('${esc(signUrl)}')">Kopyala</button>
    </div>` : ''}

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:18px">
      <div class="card">
        <div class="card-head"><div class="card-head-title">👤 Müştəri Məlumatları</div></div>
        <div class="detail-grid">
          ${dRow('Ad', c.fname)} ${dRow('Soyad', c.lname)}
          ${dRow('Ata adı', c.patronym)} ${dRow('Doğum tarixi', fmtDate(c.dob))}
          ${dRow('Ş/V №', c.idnum)} ${dRow('FİN', c.fin)}
          ${dRow('Telefon', c.phone)} ${dRow('E-poçt', c.email)}
          <div class="detail-item" style="grid-column:span 2">${dRowInline('Ünvan', c.address)}</div>
        </div>
      </div>
      <div class="card">
        <div class="card-head"><div class="card-head-title">💳 Maliyyə</div></div>
        <div class="detail-grid">
          ${dRow('Ara cəm', fmt(c.subtotal) + ' ' + c.currency)}
          ${dRow('ƏDV', fmt(c.vat) + ' ' + c.currency)}
          ${dRow('Yekun', fmt(c.total) + ' ' + c.currency)}
          ${dRow('İlkin ödəniş', fmt(c.deposit) + ' ' + c.currency)}
          ${dRow('Qalan', fmt(c.remaining) + ' ' + c.currency)}
          ${dRow('Ödəniş üsulu', c.pay_method)}
          ${dRow('Dep. tarixi', fmtDate(c.deposit_date))}
          ${dRow('Yekun tarix', fmtDate(c.final_date))}
        </div>
      </div>
    </div>

    ${itemsHtml ? `<div class="card" style="margin-bottom:16px">
      <div class="card-head"><div class="card-head-title">📦 Mallar / Xidmətlər</div></div>
      <div style="overflow-x:auto;padding:4px">${itemsHtml}</div>
    </div>` : ''}

    ${c.notes ? `<div class="card" style="margin-bottom:16px">
      <div class="card-head"><div class="card-head-title">📝 Qeydlər</div></div>
      <div class="card-body" style="font-size:13.5px;color:var(--text-soft)">${esc(c.notes)}</div>
    </div>` : ''}

    ${c.signature ? `<div class="card">
      <div class="card-head"><div class="card-head-title">✍️ İmza</div></div>
      <div class="card-body">${sigImg}</div>
    </div>` : ''}
  `;
}

function dRow(label, val) {
  return `<div class="detail-item"><label>${esc(label)}</label><div class="val">${esc(String(val||'—'))}</div></div>`;
}
function dRowInline(label, val) {
  return `<label>${esc(label)}</label><div class="val">${esc(String(val||'—'))}</div>`;
}

function copyLink(url) {
  navigator.clipboard.writeText(url).then(() => showToast('Link kopyalandı', 'ok')).catch(() => showToast('Kopyalanmadı', 'err'));
}

// ══════════════════════════════════════════════
//  YENİ MÜQAVİLƏ — WIZARD
// ══════════════════════════════════════════════
let wizStep = 1;
const WIZ_TOTAL = 4;
let vatIncluded = true;
const contractItems = [];

function goWiz(step) {
  if (step < 1 || step > WIZ_TOTAL) return;
  wizStep = step;
  $$('.wiz-step').forEach((el, i) => {
    el.classList.toggle('active', i + 1 === step);
    el.classList.toggle('done', i + 1 < step);
  });
  $$('.wiz-section').forEach(s => s.classList.toggle('active', parseInt(s.dataset.step) === step));
  document.getElementById('wizPrev').style.display = step > 1 ? '' : 'none';
  document.getElementById('wizNext').textContent = step < WIZ_TOTAL ? 'İrəli →' : '✓ Müqavilə Yarat';
}

document.getElementById('wizNext')?.addEventListener('click', () => {
  if (wizStep < WIZ_TOTAL) {
    goWiz(wizStep + 1);
  } else {
    submitContract();
  }
});
document.getElementById('wizPrev')?.addEventListener('click', () => goWiz(wizStep - 1));

// VAT toggle
document.getElementById('vatBox')?.addEventListener('click', function() {
  vatIncluded = !vatIncluded;
  this.classList.toggle('on', vatIncluded);
  this.classList.toggle('off', !vatIncluded);
  const txt = this.querySelector('.vat-text strong');
  const sub = this.querySelector('.vat-text span');
  if (txt) txt.textContent = vatIncluded ? 'ƏDV Daxildir (18%)' : 'ƏDV Yoxdur';
  if (sub) sub.textContent = vatIncluded ? 'Qiymətlərə ƏDV daxildir' : 'Qiymətlər ƏDV-siz göstərilir';
  recalc();
});

// Items
function addItemRow(data = {}) {
  const tbody = document.getElementById('itemsTbody');
  const idx   = contractItems.length;
  contractItems.push({ name: '', qty: 1, unit: 'əd', price: 0 });
  const tr = document.createElement('tr');
  tr.dataset.idx = idx;
  tr.innerHTML = `
    <td>${idx + 1}</td>
    <td><input type="text" placeholder="Məhsul adı" value="${esc(data.name||'')}" onchange="updateItem(${idx},'name',this.value)"></td>
    <td><input type="text" placeholder="əd" value="${esc(data.unit||'əd')}" style="width:60px" onchange="updateItem(${idx},'unit',this.value)"></td>
    <td><input type="number" min="1" step="1" value="${data.qty||1}" style="width:70px" onchange="updateItem(${idx},'qty',this.value)"></td>
    <td><input type="number" min="0" step="0.01" value="${data.price||0}" style="width:100px" oninput="updateItem(${idx},'price',this.value)"></td>
    <td class="num" id="itemTotal_${idx}">0.00</td>
    <td><button class="del-row-btn" onclick="removeItem(this,${idx})">✕</button></td>`;
  tbody.appendChild(tr);
  recalc();
}

function updateItem(idx, field, val) {
  if (!contractItems[idx]) return;
  contractItems[idx][field] = field === 'qty' || field === 'price' ? parseFloat(val)||0 : val;
  recalc();
}

function removeItem(btn, idx) {
  btn.closest('tr').remove();
  contractItems[idx] = null;
  recalc();
}

document.getElementById('addItemBtn')?.addEventListener('click', () => addItemRow());

function recalc() {
  let subtotal = 0;
  contractItems.forEach((it, i) => {
    if (!it) return;
    const t = (it.qty||1) * (it.price||0);
    subtotal += t;
    const el = document.getElementById('itemTotal_' + i);
    if (el) el.textContent = fmt(t);
  });
  const vatRate = 18;
  const vat     = vatIncluded ? Math.round(subtotal * vatRate / (100 + vatRate) * 100) / 100 : 0;
  const total   = subtotal;
  const deposit = parseFloat(document.getElementById('fDeposit')?.value || 0);
  const remaining = total - deposit;

  setVal('fSubtotal',  subtotal.toFixed(2));
  setVal('fVat',       vat.toFixed(2));
  setVal('fTotal',     total.toFixed(2));
  setVal('fRemaining', remaining.toFixed(2));
  setText('dispSubtotal', fmt(subtotal) + ' AZN');
  setText('dispVat',      (vatIncluded ? '18% · ' : '') + fmt(vat) + ' AZN');
  setText('dispTotal',    fmt(total) + ' AZN');
  setText('dispDeposit',  fmt(deposit) + ' AZN');
  setText('dispRemaining',fmt(remaining) + ' AZN');
}

function setVal(id, v) { const el = document.getElementById(id); if (el) el.value = v; }
document.getElementById('fDeposit')?.addEventListener('input', recalc);

async function submitContract() {
  const get = id => (document.getElementById(id)?.value || '').trim();
  const payload = {
    fname: get('fFname'), lname: get('fLname'), patronym: get('fPatronym'),
    dob: get('fDob'), idnum: get('fIdnum'), fin: get('fFin'),
    idissue: get('fIdissue'), idexpiry: get('fIdexpiry'), idauth: get('fIdauth'),
    address: get('fAddress'), delivery: get('fDelivery'),
    phone: get('fPhone'), email: get('fEmail'),
    items: contractItems.filter(Boolean),
    vatIncluded,
    subtotal: parseFloat(get('fSubtotal')||0),
    vat:      parseFloat(get('fVat')||0),
    total:    parseFloat(get('fTotal')||0),
    deposit:  parseFloat(get('fDeposit')||0),
    remaining:parseFloat(get('fRemaining')||0),
    depositDate: get('fDepositDate'), finalDate: get('fFinalDate'),
    installDate: get('fInstallDate'), warranty: get('fWarranty')||'12 ay',
    payMethod: get('fPayMethod')||'Nağd', currency: get('fCurrency')||'AZN',
    notes: get('fNotes'),
  };

  if (!payload.fname || !payload.lname || !payload.idnum || !payload.phone || !payload.address) {
    showToast('Zəruri sahələri doldurun', 'err');
    goWiz(1);
    return;
  }

  const btn = document.getElementById('wizNext');
  btn.disabled = true;
  btn.innerHTML = '<div class="spinner" style="display:inline-block"></div> Yaradılır...';

  try {
    const c = await apiFetch(`${API}?action=contracts`, { method: 'POST', body: JSON.stringify(payload) });
    showToast('Müqavilə yaradıldı: ' + c.contract_no, 'ok');
    resetWizard();
    showPage('contracts');
    setTimeout(() => openDetail(c.id), 400);
  } catch (e) {
    showToast(e.message, 'err');
  } finally {
    btn.disabled = false;
    btn.textContent = '✓ Müqavilə Yarat';
  }
}

function resetWizard() {
  $$('#newPage input, #newPage select, #newPage textarea').forEach(el => el.value = '');
  contractItems.length = 0;
  const tbody = document.getElementById('itemsTbody');
  if (tbody) tbody.innerHTML = '';
  vatIncluded = true;
  const vb = document.getElementById('vatBox');
  if (vb) { vb.classList.add('on'); vb.classList.remove('off'); }
  recalc();
  goWiz(1);
}

document.getElementById('btnNewContract')?.addEventListener('click', () => showPage('new'));
document.getElementById('btnNewContract2')?.addEventListener('click', () => showPage('new'));

// ══════════════════════════════════════════════
//  TƏNZİMLƏMƏLƏR
// ══════════════════════════════════════════════
async function loadSettings() {
  try {
    const s = await apiFetch(`${API}?action=settings`);
    const fields = ['company_name','voen','phone','director','address','email','vat_rate'];
    fields.forEach(f => setVal('set_' + f, s[f] ?? ''));
    // Müqavilə şərtləri
    const termsEl = document.getElementById('set_contract_terms');
    if (termsEl) termsEl.value = s['contract_terms'] ?? '';
  } catch (e) { showToast(e.message, 'err'); }
}

document.getElementById('settingsForm')?.addEventListener('submit', async e => {
  e.preventDefault();
  const data = {};
  ['company_name','voen','phone','director','address','email','vat_rate'].forEach(f => {
    data[f] = document.getElementById('set_' + f)?.value || '';
  });
  try {
    await apiFetch(`${API}?action=settings`, { method: 'POST', body: JSON.stringify(data) });
    showToast('Şirkət məlumatları saxlanıldı', 'ok');
  } catch (e) { showToast(e.message, 'err'); }
});

document.getElementById('passForm')?.addEventListener('submit', async e => {
  e.preventDefault();
  const old_password = document.getElementById('oldPass')?.value || '';
  const new_password = document.getElementById('newPass')?.value || '';
  const confirm_password = document.getElementById('confirmPass')?.value || '';
  if (new_password !== confirm_password) { showToast('Yeni şifrələr uyğun gəlmir', 'err'); return; }
  try {
    const r = await apiFetch(`${API}?action=change_password`, { method: 'POST', body: JSON.stringify({ old_password, new_password }) });
    showToast(r.message || 'Şifrə dəyişdirildi', 'ok');
    e.target.reset();
  } catch (err) { showToast(err.message, 'err'); }
});

// ── HELPERS ───────────────────────────────────
function statusClass(s) {
  return { pending: 'badge-pending', sent: 'badge-sent', signed: 'badge-signed', cancelled: 'badge-cancelled' }[s] || '';
}
function statusLabel(s) {
  return { pending: 'Gözləyir', sent: 'Göndərilib', signed: 'İmzalandı', cancelled: 'Ləğv edildi' }[s] || s;
}

// ── INIT ──────────────────────────────────────
showPage('dashboard');
loadSettings();
goWiz(1);
addItemRow();
