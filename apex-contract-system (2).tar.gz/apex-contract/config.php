<?php
// ══════════════════════════════════════════════
//  APEX INDUSTRIES MMC — Konfiqurasiya
//  config.php
// ══════════════════════════════════════════════

// ── VERİLƏNLƏR BAZASI ─────────────────────────
define('DB_HOST',    'localhost');
define('DB_NAME',    'apex_db');
define('DB_USER',    'apex_user');
define('DB_PASS',    'STRONG_PASS');
define('DB_CHARSET', 'utf8mb4');

// ── ADMIN GİRİŞ ────────────────────────────────
define('ADMIN_USER', 'admin');
define('ADMIN_PASS', '$2y$12$YourHashedPasswordHere'); // php -r "echo password_hash('yourpassword', PASSWORD_BCRYPT, ['cost'=>12]);"

// ── ŞIRKƏT DEFOLT DƏYƏRLƏRİ ───────────────────
define('DEFAULT_COMPANY',  'Apex Industries MMC');
define('DEFAULT_VOEN',     '2006367471');
define('DEFAULT_PHONE',    '050 400 33 55');
define('DEFAULT_DIRECTOR', 'Elşan Heydarov');
define('DEFAULT_ADDRESS',  'Bakı şəh., Nərimanov r.');
define('DEFAULT_VAT',      18);

// ── APP AYARLARI ───────────────────────────────
define('APP_NAME',    'Apex Industries MMC');
define('APP_VERSION', '2.0');
define('SESSION_NAME','apex_session');

// ── TƏHLÜKƏSİZLİK ─────────────────────────────
if (getenv('APP_ENV') !== 'development') {
    error_reporting(0);
    ini_set('display_errors', '0');
}

// ── VAXT ZONASI ────────────────────────────────
date_default_timezone_set('Asia/Baku');

// ── SESSION ────────────────────────────────────
if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_set_cookie_params([
        'lifetime' => 28800,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}
